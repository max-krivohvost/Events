<?php

class WP_Query_Multisite
{
    private $global_sites = array(1, 2);
    private static $post_type = null;

    function __construct()
    {
        add_filter('posts_request', array($this, 'posts_request'), 10, 2);
    }

    function query_vars($vars)
    {
        $vars[] = 'multisite';
        $vars[] = 'sites__not_in';
        $vars[] = 'sites__in';
        return $vars;
    }

    function posts_request($query, $sql)
    {
        if (!empty($_POST['test'])) {
            file_put_contents(__DIR__ . '/query.log', $query . "\n\n", FILE_APPEND);
        }
        $sql_query = $sql->query;

        self::$post_type = $sql_query['post_type'];

        $post_type_is_tribe_event = false;
        if (!empty($sql_query['post_type']) && $sql_query['post_type'] == 'tribe_events') {
            $post_type_is_tribe_event = true;
        }

        if ($post_type_is_tribe_event && is_single()) {
            return $query;
        }

        $current_blog_id = $blog_id = get_current_blog_id();

        $is_local_site = !in_array($blog_id, $this->global_sites);

        $select_site = !empty($_REQUEST['select-site']) ? (int)$_REQUEST['select-site'] : 0;

        if (!$is_local_site) {
            if ($select_site == 1 || (empty($select_site) && $blog_id == 1)) {
                $prefix = 'dxcvz';
                $prefix_change = 'dxcvz_2';
            } else {
                $prefix = 'dxcvz_2';
                $prefix_change = 'dxcvz';
            }
        } else {
            $prefix = 'dxcvz_' . $blog_id;
            $prefix_change = 'dxcvz';
            $prefix_change2 = 'dxcvz_2';
        }

        $is_admin = is_admin();
        $is_set_request_uri = !empty($_SERVER['REQUEST_URI']);
        $not_admin_ajax = $is_set_request_uri && strpos($_SERVER['REQUEST_URI'], '/wp-admin/admin-ajax.php') === false;


        if ($is_admin && $not_admin_ajax) {
            return $query;
        }

//        $query = str_replace('SQL_CALC_FOUND_ROWS', '', $query);
        $query = preg_replace('/\s\s+/', ' ', $query);
        $query = str_replace(["\n", '1=1 AND '], '', $query);
        $query = str_replace('( 0 = 1) AND ', '', $query);

        $query_for_local_region = $query;

        $is_set_instance = !empty($sql_query['instance']);

        if ($is_set_instance) {
            $instance = $sql_query['instance'];
            $show_all_events = $is_set_instance && $instance['show_all_events'] == 'on';

            if ($show_all_events) {
                $query = str_replace('0 = 1 AND', '', $query);
                return $query;
            }
        }


        $show_both_sites = false;
        $region_area = !empty($_REQUEST['region-area']) ? $_REQUEST['region-area'] : '';
        if (!empty($instance['show_both_sites'])) {
            if ($instance['show_both_sites'] == 'on') {
                $show_both_sites = true;
            }
        }

        if (!empty($sql_query['show_both_sites'])) {
            if ($sql_query['show_both_sites'] == 'on') {
                $show_both_sites = true;
            }
        }

        if (isset($_REQUEST['region-area']) && empty($_REQUEST['select-site'])) {
            $show_both_sites = true;
        }

        $tribe_render_context_is_widget = false;
        if (!empty($sql_query['tribe_render_context']) && $sql_query['tribe_render_context'] == 'widget') {
            $tribe_render_context_is_widget = true;
        }


        $use_local_region = false;
        $region_area_is_kalender = false;
        if (!empty($sql_query['region-area-kalender']) && $sql_query['region-area-kalender']) {
            $region_area_is_kalender = true;
            $region_area = $sql_query['region-area-kalender'];
        }

        if (!empty($instance['local-region-area-kalender'])) {
            $use_local_region = true;
        }

        $request_uri_is_kalender = false;
        if ($is_set_request_uri) {
            if ($_SERVER['REQUEST_URI'] == '/kalender/') {
                $request_uri_is_kalender = true;
            } elseif ($_SERVER['REDIRECT_URL'] == '/kalender/lista/') {
                $request_uri_is_kalender = true;
            }
        }

        $action_is_tribe_list = false;
        if (!empty($_REQUEST['action']) && $_REQUEST['action'] == 'tribe_list') {
            $action_is_tribe_list = true;
        }

        $switch_to_blog_id = 1;
        if ($select_site == 1 || $blog_id == 1) {
            $switch_to_blog_id = 2;
        }

        if ($show_both_sites
            || ($tribe_render_context_is_widget && $show_both_sites)
            || ($region_area_is_kalender && $tribe_render_context_is_widget)
            || $request_uri_is_kalender
            || $action_is_tribe_list
            || $post_type_is_tribe_event
        ) {
            $category_area = !empty($_REQUEST['category-area']) && $_REQUEST['category-area'] ? $_REQUEST['category-area'] : 0;

            if (!empty($select_site) && !empty($select_site)) {
                switch_to_blog($select_site);
            }

            if ($category_area != 0) {
                $category = get_term_by('term_id', $category_area, 'tribe_events_cat');

                $switched_site = false;

                // If category not exists in selected blog, changing blog and try again
                if (empty($category)) {
                    switch_site:
                    $switched_site = true;
                    switch_to_blog($switch_to_blog_id);
                    $category = get_term_by('term_id', $category_area, 'tribe_events_cat');

                    // Return to current blog
                    switch_to_blog($current_blog_id);
                }

                $category = get_term_by('slug', $category->slug, 'tribe_events_cat');

                // Return to current blog
                switch_to_blog($current_blog_id);

                // If not exist category and blog not changed for search category, we do it now
                if (empty($category) && !$switched_site) {
                    goto switch_site;
                }

                $categories = $category_area;
                if (!empty($category)) {
                    $categories .= ',' . $category->term_id;
                }

                $str = substr($query, strpos($query, 'GROUP BY'));
                $query = str_replace($str, '', $query);
                $inner_join = 'INNER JOIN ' . $prefix . '_term_relationships ON (' . $prefix . '_posts.ID = ' . $prefix . '_term_relationships.object_id) ';
                $query = substr_replace($query, $inner_join, strpos($query, 'WHERE'), 0);
                $query = $query . 'AND ( ' . $prefix . '_term_relationships.term_taxonomy_id IN (' . $categories . ') )';
                $query = $query . $str;
            }

            if (!empty($_REQUEST['region-area'])) {
                $query = $this->add_region_filter($query, ($select_site == 2 && $blog_id == 1 ? $prefix_change : $prefix), $_REQUEST['region-area']);
            }

            if ($region_area_is_kalender && $tribe_render_context_is_widget) {
                $query = $this->add_region_filter($query, $prefix, $sql_query['region-area-kalender']);
            }

            if (!$is_local_site && $select_site && $select_site != $current_blog_id) {
                $query = str_replace($prefix_change, $prefix, $query);
            }

            $str = substr($query, strpos($query, 'ORDER BY'));
            $suggest_query = str_replace($str, '', $query);

            $is_applied_both_sites = false;

            if (!$is_local_site) {
                switch_to_blog($current_blog_id);

                $merge = false;

                if ($post_type_is_tribe_event) {
                    if (((!$select_site) && !$tribe_render_context_is_widget) || ($tribe_render_context_is_widget && $show_both_sites)) {
                        $str_for_both_sites = substr($query, strpos($query, 'ORDER BY'));
                        $query = str_replace($str_for_both_sites, '', $query);

                        $query1 = $query;
                        $query1 = str_replace('SQL_CALC_FOUND_ROWS', '', $query1);

                        $this->join_tribe_event_end_date($query, $query1, $prefix, $prefix_change);

                        if ($show_both_sites) {
                            $query = $this->both_sites($query, $query1, false, true);
                            $query1 = $this->both_sites($query, $query1, false);
                        }

                        $query = $this->add_union($query, $query1, '', '');

                        $query .= ' ' . $str_for_both_sites;

                        $is_applied_both_sites = true;
                        $merge = true;
                    } elseif ($select_site || $tribe_render_context_is_widget) {
                        $query1 = $query;
                        $query1 = str_replace('SQL_CALC_FOUND_ROWS', '', $query1);

                        $this->join_tribe_event_end_date($query, $query1, $prefix, $prefix_change);

                        if ($show_both_sites || !$tribe_render_context_is_widget) {
                            // We should showing all both sites events
                            $query = $this->both_sites($query, $query1);
                        }


                        $is_applied_both_sites = true;
                        $merge = true;
                    }
                }

                $str = substr($query, strpos($query, 'ORDER BY'));
                $query = str_replace($str, '', $query);

                $blogs_events = array();

                if (!$select_site || $select_site == $current_blog_id) {
                    $mypod = pods('local_events');
                    $mypod->find(array(
                        'where' => "event_status.meta_value LIKE 'a' and t.post_status = 'draft'"
                    ));


                    while ($mypod->fetch()) {
                        $blogs_events[$mypod->display('blog_id')][$mypod->display('event_id')] = $mypod->display('event_id');
                    }
                }

                if (!$select_site || ($select_site != $current_blog_id)) {

                    if (($tribe_render_context_is_widget && $show_both_sites) || !$tribe_render_context_is_widget) {

                        switch_to_blog(($select_site && $select_site != $current_blog_id ? $select_site : $switch_to_blog_id));
                        PodsAPI::$instances = array();

                        $mypod2 = pods('local_events');
                        $mypod2->find(array(
                            'where' => "event_status.meta_value LIKE 'a' and t.post_status = 'draft'"
                        ));

                        while ($mypod2->fetch()) {
                            $blogs_events[$mypod2->display('blog_id')][$mypod2->display('event_id')] = $mypod2->display('event_id');
                        }

                        switch_to_blog($current_blog_id);
                    }
                }


                foreach ($blogs_events as $event_blog_id => $approved_event_ids) {
                    if (!empty($approved_event_ids)) {
                        $approved_event_where = " AND {$prefix}_posts.ID IN("
                            . implode(',', $approved_event_ids) . ') ';

                        $event_blog_prefix = explode('_', $prefix)[0] . '_' . $event_blog_id;

                        $tmp_suggest_query = str_replace("AND {$prefix}_posts.post_type",
                            "{$approved_event_where}AND {$prefix}_posts.post_type", $suggest_query);

                        $tmp_suggest_query = str_replace('region_value.meta_value LIKE "%' . $region_area . '%"',
//                            "(region_value.meta_value LIKE '%{$_REQUEST['region-area']}%' OR "
                            "("
                            . "EXISTS( SELECT 1 FROM dxcvz_sitemeta WHERE meta_key LIKE '_subsite_{$event_blog_id}'"
                            . " AND meta_value LIKE '%" . $region_area . "%'))", $tmp_suggest_query);


                        if ($is_applied_both_sites && $show_both_sites) {
                            $tmp_suggest_query = str_replace(' FROM ', ', 1 show_both_site FROM ', $tmp_suggest_query);
                        }

                        $tmp_suggest_query = str_replace('SQL_CALC_FOUND_ROWS', '', $tmp_suggest_query);

                        $query = $this->add_union($query, $tmp_suggest_query, $prefix, $event_blog_prefix, $merge);
                    }
                }
            }

            // If not set site
            if (empty($select_site)) {

                if (!empty($sql_query['tax_query_network'])) {
                    $CategoryStartСondition = strpos($query, 'term_taxonomy_id IN');


                    if ($CategoryStartСondition) {

                        $category_part_start = strpos($query, '(', $CategoryStartСondition);
                        $category_part_end = strpos($query, ')', $CategoryStartСondition);
                        $CategoryMainСondition = substr($query, $category_part_start, ($category_part_end - $category_part_start) + 1);

                        if (!empty($sql_query['tax_query'][0]['terms'])) {
                            $categories = implode(',', ($sql_query['tax_query_network'][0]['terms']));

                            $query_second = str_replace($CategoryMainСondition, '(' . $categories . ')', $query);
                            $query_second = str_replace('SQL_CALC_FOUND_ROWS', '', $query_second);
                        }

                    } else {

                        $CategoryStartСondition = strpos($query, '0 = 1');
                        $query_second = $query;
                        $query_second = str_replace('SQL_CALC_FOUND_ROWS', '', $query_second);

                        $category_part_end = strpos($query, ')', $CategoryStartСondition);

                        if (!empty($sql_query['tax_query'][0]['terms'])) {
                            $categories = implode(',', ($sql_query['tax_query_network'][0]['terms']));
                            $query_second = substr_replace($query_second, ' AND ' . $prefix . '_term_relationships.term_taxonomy_id IN(' . $categories . ')', $category_part_end + 1, 0);
                        }
                    }

                    if (!$post_type_is_tribe_event) {
                        $InnerJoinCondition = strpos($query_second, 'LEFT JOIN ' . $prefix . '_term_relationships ON');

                        if (!$InnerJoinCondition) {
                            $to_search = 'FROM ' . $prefix . '_posts';

                            $InnerJoinPlaceConditionOld = strpos($query_second, $to_search);
                            $InnerJoinPlaceConditionNew = (string)strlen($to_search);
                            $insertString = ' LEFT JOIN dxcvz_term_relationships ON ( dxcvz_posts.ID = dxcvz_term_relationships.object_id ) ';

                            $query_second = substr_replace($query_second, $insertString, $InnerJoinPlaceConditionNew
                                + $InnerJoinPlaceConditionOld, 0);
                        }

                        $str = str_replace($prefix . '_posts.', '', $str);
                    }

                    $query = $this->add_union($query, $query_second, $prefix, $prefix_change);

                } else {
                    if ($tribe_render_context_is_widget && !$show_both_sites) {

                    } elseif ($post_type_is_tribe_event) {
                        $tmp_query = $query;

                        $tmp_query = str_replace('SQL_CALC_FOUND_ROWS', '', $tmp_query);

                        if ($is_local_site && empty($GLOBALS['ical'])) {
                            global $wpdb;
                            $region_query = "SELECT meta_value FROM {$wpdb->sitemeta} WHERE meta_key = '_subsite_{$current_blog_id}'";
                            $local_region = mb_strtolower($wpdb->get_var($region_query));

                            $tmp_query = str_replace("WHERE ", "WHERE 
                                (ge.post_id IS NOT NULL OR ge2.post_id IS NOT NULL OR 
                                (ge3.meta_value IS NOT NULL) " .
                                (get_option('_show_events_from_national', 0) != 0 ? ' OR (1=1)' : '')
                                . ") AND ", $tmp_query);

                            $new_query = str_replace("LEFT JOIN {$prefix}_postmeta", "LEFT JOIN {$prefix_change}_postmeta as ge 
                            ON (ge.post_id = {$prefix}_posts.ID AND ge.meta_key='_subsite_{$blog_id}') 
                            
                            LEFT JOIN {$prefix}_postmeta as ge2 ON (ge2.post_id = {$prefix}_posts.ID 
                                AND ge2.meta_key='_subsite_added_{$blog_id}')
                            
                            LEFT JOIN {$prefix}_postmeta as ge3 ON (ge3.post_id = {$prefix}_posts.ID 
                                AND ge3.meta_key='_region_{$local_region}')
                            
                            LEFT JOIN {$prefix}_postmeta", $tmp_query);

                            if ($_POST['local_widget'] != 'yes') {
                                $query = $this->add_union($query, $new_query, $prefix, $prefix_change);
                            } else {
                                $query = $this->add_union('', $new_query, $prefix, $prefix_change);
                                $query = str_replace('() UNION', '', $query);
                            }


                            $new_query = str_replace("LEFT JOIN {$prefix}_postmeta", "LEFT JOIN {$prefix_change2}_postmeta as ge 
                            ON (ge.post_id = {$prefix}_posts.ID AND ge.meta_key='_subsite_{$blog_id}') 
                            
                            LEFT JOIN {$prefix}_postmeta as ge2 ON (ge2.post_id = {$prefix}_posts.ID 
                                AND ge2.meta_key='_subsite_added_{$blog_id}')
                            
                            LEFT JOIN {$prefix}_postmeta as ge3 ON (ge3.post_id = {$prefix}_posts.ID 
                                AND ge3.meta_key='_region_{$local_region}')
                            
                            LEFT JOIN {$prefix}_postmeta", $tmp_query);

                            $query = $this->add_union($query, $new_query, $prefix, $prefix_change2, true);
                        }
                    }
                }

                $query = str_replace($str, '', $query);
                $query .= ' ' . $str;

            } else { // Site is set
                $query = str_replace($str, '', $query);
                $query .= ' ' . $str;
                $query1 = $query;

                $query1 = str_replace('SQL_CALC_FOUND_ROWS', '', $query1);

                // If not local site
                if ($is_local_site) { // If local sites
                    $tmp_query = str_replace("WHERE ", "WHERE 
                            (ge.post_id IS NOT NULL OR ge2.post_id IS NOT NULL) AND ", $query1);

                    if ($select_site == 1 || $select_site == 2) {

                        $tmp_query = str_replace("LEFT JOIN {$prefix}_postmeta", "LEFT JOIN {$prefix}_postmeta as ge 
                            ON (ge.post_id = {$prefix}_posts.ID 
                                AND ge.meta_key='_subsite_{$blog_id}')
                                 
                            LEFT JOIN {$prefix}_postmeta as ge2 ON (ge2.post_id = {$prefix}_posts.ID 
                                AND ge2.meta_key='_subsite_added_{$blog_id}')
                                    
                            LEFT JOIN {$prefix}_postmeta", $tmp_query);

                        $query = str_replace("{$prefix}", $select_site == 1 ? $prefix_change : $prefix_change2, $tmp_query);

                    }

                }
            }
        }

        $category_ids = !empty($_REQUEST['category_ids']) ? $_REQUEST['category_ids'] : '';

        if (!empty($category_ids)) {
            $query = $this->add_category_filter($query, $prefix, $category_ids, $sql->query_vars['cat']);
        }

        // Return to current blog
        switch_to_blog($current_blog_id);

        if ($tribe_render_context_is_widget && $use_local_region) {
            // Show only local sites events by region
            $query_for_local_region = str_replace('SQL_CALC_FOUND_ROWS ', '', $query_for_local_region);
            $str_for_local_region = substr($query_for_local_region, strpos($query_for_local_region, 'ORDER BY'));
            $query_for_local_region = str_replace($str_for_local_region, '', $query_for_local_region);

            if ($region_area_is_kalender) {
                $query_for_local_region = str_replace('EventStartDate,',
                    "EventStartDate,\n'{$region_area}' as RegionValue,\n", $query_for_local_region);
            }

            $query_for_local_region = $this->union_local_region($query_for_local_region, $prefix, $instance['local-region-area-kalender'], false, $show_both_sites);

            // Return to current blog
            switch_to_blog($current_blog_id);

            if ($query_for_local_region) {
                $merge = false;

                if (strpos($query, 'UNION') !== false) {
                    $merge = true;
                }

                $str = substr($query, strpos($query, 'ORDER BY'));
                $query = str_replace($str, '', $query);
                $query = $this->add_union($query, $query_for_local_region, null, null, $merge);

                $query .= ' ' . $str;
            }
        }


        if ($post_type_is_tribe_event) {
            $show_logs = !empty($_REQUEST['dbg2']);

            if ($show_logs) {
                ob_end_clean();
                ob_start();
            }

            if ($show_logs) {

                eqm_log($query);

                eqm_log("Blog ID: " . get_current_blog_id());

                echo ob_get_clean();
                die();
            }
        }

        /**
         * Show posts from the region of the national site and from the region of local sites
         */

        $is_related_post_query = (is_single() && get_post_type() == 'post');

        if (!empty($sql_query['post_type']) && $sql_query['post_type'] == 'post'
            && (get_option('_show_posts_from_national', 0) || get_option('_show_posts_from_local_region', 0)) && !$is_related_post_query) {

            $str = substr($query, strpos($query, ' ORDER BY'));
            $query = str_replace($str, '', $query);

            $tmp_query = $tmp_query2 = $query;
            $tmp_query = str_replace('SQL_CALC_FOUND_ROWS ', '', $tmp_query);

            $tmp_query = str_replace('WHERE',
                "LEFT JOIN {$prefix}_term_relationships tr ON (tr.object_id = {$prefix}_posts.ID) " .
                "LEFT JOIN {$prefix}_terms t ON (t.term_id = tr.term_taxonomy_id) WHERE", $tmp_query);

            $region = get_region_name();
            $tmp_query = str_replace("'post' AND", "'post' AND t.name LIKE 'Region {$region}' AND", $tmp_query);

            if (get_option('_show_posts_from_national', 0)) {
                $query = self::add_union($query, $tmp_query, $prefix, $prefix_change);
                $query = self::add_union($query, $tmp_query, $prefix, $prefix_change2, true);
            }

            $show_logs = !empty($_REQUEST['dbg']);

            if ($show_logs) {
                ob_end_clean();
                ob_start();
            }

            if (get_option('_show_posts_from_local_region', 0)) {
                if (get_option('_show_posts_from_national', 0)) {
                    $tmp_query2 = str_replace('SQL_CALC_FOUND_ROWS ', '', $tmp_query2);
                    $query .= ' UNION ' . self::union_local_region($tmp_query2, $prefix, $region, true);
                } else {
                    $query = self::union_local_region($tmp_query2, $prefix, $region);
                }
            }

            $str = str_replace("{$prefix}_posts.", '', $str);

            $query .= ' ' . $str;

            if ($show_logs) {

                eqm_log($sql_query);
                eqm_log($query);

                eqm_log("Blog ID: " . get_current_blog_id());
                eqm_log("Show posts from national sites: "
                    . (get_option('_show_posts_from_national', 0) != 0
                        ? 'true' : 'false'));


                echo ob_get_clean();
                die();
            }
        }

//	    file_put_contents(__DIR__ .'/query.log',
//		    str_pad( '-- ' . date( 'Y-m-d H:i:s' ) . ' ', 100, '-' )
//		    . "\n" . $query . "\n\n", FILE_APPEND );

        return $query;
    }

    private function join_tribe_event_end_date(&$query, &$query1, $prefix, $prefix_change, $revert = false)
    {
        $query1 = str_replace(" LEFT JOIN {$prefix}_postmeta as tribe_event_end_date ",
            " LEFT JOIN {$prefix}_postmeta AS tribe_event_end_date1 ON ({$prefix}_posts.ID = tribe_event_end_date1.post_id AND
              tribe_event_end_date1.meta_key =
              'ttfmp_per-page_show-both-site') LEFT JOIN {$prefix}_postmeta as tribe_event_end_date ", $query1);

        if ($revert) {
            $query = str_replace($prefix, $prefix_change, $query);
        } else {
            $query1 = str_replace($prefix, $prefix_change, $query1);
        }
    }

    private function add_union($query, $query1, $prefix, $prefix_change, $merge = false)
    {
        if (!$merge) {
            $query = '(' . $query . ') UNION (' . str_replace($prefix, $prefix_change, $query1) . ')';
        } else {
            $query .= ' UNION (' . str_replace($prefix, $prefix_change, $query1) . ')';
        }

        $query = str_replace($prefix_change . '_sitemeta', $prefix . '_sitemeta', $query);

        return $query;
    }

    private function add_category_filter($query, $prefix, $category_ids, $query_vars_cat = null)
    {
        $join = ' LEFT JOIN ' . $prefix . '_term_taxonomy ON ('
            . $prefix . '_term_relationships.term_taxonomy_id = '
            . $prefix . '_term_taxonomy.term_taxonomy_id) WHERE ';


        $query = str_replace('WHERE', $join, $query);

        $category_ids = str_replace('|', ',', $category_ids);

        if (!is_null($query_vars_cat)) {
            $to_search_multiple = '' . $prefix . '_term_relationships.term_taxonomy_id IN (' . $query_vars_cat . ')';
        }

        $to_change_multiple = '' . $prefix . '_term_relationships.term_taxonomy_id IN (' . $category_ids . ')';
        $to_change_multiple .= ' AND taxonomy = "category" ';

        return str_replace($to_search_multiple, $to_change_multiple, $query);
    }

    private function add_region_filter($query, $prefix, $search_value)
    {
        $clause = 'AND region_value.meta_value LIKE "%' . $search_value . '%"';
        $query = substr_replace($query, $clause, strpos($query, 'GROUP BY'), 0);
        $clause = ", MIN( region_value.meta_value) as RegionValue";
        $query = substr_replace($query, "as EventStartDate " . $clause,
            strpos($query, 'as EventStartDate'), strlen('as EventStartDate'));
        $clause = " LEFT JOIN " . $prefix . "_postmeta as region_value ON ( "
            . $prefix . "_posts.ID = region_value.post_id AND region_value.meta_key = '_ecp_custom_2' )";

        return substr_replace($query, "_EventEndDate' )" . $clause,
            strpos($query, "_EventEndDate' )"), strlen("_EventEndDate' )"));
    }

    /**
     * This function change prefix for query to first found sub site and use union for other sub sites
     * @param $query
     * @param $prefix
     * @param $search_value
     * @return mixed|string
     */
    private function union_local_region($query, $prefix, $search_value, $without_input_query = false, $show_both_sites = false)
    {
        global $wpdb;

        $subsites = $wpdb->get_results('
          SELECT REPLACE(meta_key, \'_subsite_\', \'\') as blog_id, b.path
          FROM dxcvz_sitemeta 
          LEFT JOIN dxcvz_blogs b ON (b.blog_id = REPLACE(meta_key, \'_subsite_\', \'\'))
          WHERE meta_value LIKE \'' . $search_value . '\' AND meta_key LIKE \'_subsite_%\' AND b.path IS NOT NULL');

        $exists_tables = $wpdb->get_col('
          SELECT * 
          FROM information_schema.tables WHERE TABLE_NAME LIKE \'dxcvz_%_posts\'', 2);

        $changed_prefix = false;
        if (!empty($subsites)) {
            $query1 = $query;

            $query1 = str_replace('SQL_CALC_FOUND_ROWS ', '', $query1);

            $merge = false;
            foreach ($subsites as $key => $obj) {
                $id = $obj->blog_id;
                $prefix_change = 'dxcvz_' . $id;

                if (strpos($obj->path, '/new') !== false) {
                    continue;
                }

                if ($prefix_change == $prefix && $without_input_query) {
                    continue;
                }

                if (!get_blog_option($id, '_subsite_show_events_in_widgets', 0) && (!get_option('_show_posts_from_local_region', 0) || self::$post_type != 'post')) {
                    continue;
                }

                if (!in_array($prefix_change . '_posts', $exists_tables)) {
                    continue;
                }

                if (!$changed_prefix) {
                    if ($show_both_sites) {
                        // If we should have field show_both_sites
                        $query = $this->both_sites($query1, '', false, true);
                    }

                    $query = str_replace($prefix, $prefix_change, $query);
                    $changed_prefix = true;
                    continue;
                }

                $tmp_query1 = $query1;
                if ($show_both_sites) {
                    // If we should have field show_both_sites
                    $tmp_query1 = $this->both_sites($tmp_query1, '', false, true);
                }

                $query = $this->add_union($query, $tmp_query1, $prefix, $prefix_change, $merge);
                $merge = true;
            }
        }

        if (!$changed_prefix) {
            return null;
        }

        return $query;
    }

    private function both_sites($query, $query1, $union = true, $return_query = false)
    {
        $query = str_replace(' FROM ', ", 1 show_both_site" . ' FROM ', $query);

        $query1 = str_replace(' FROM ', ', '
            . "COUNT(IF (tribe_event_end_date1.meta_key = 'ttfmp_per-page_show-both-site', 
                        tribe_event_end_date1.meta_value, null)) show_both_site" . ' FROM ', $query1);

        $query1 = str_replace(' ORDER BY ', ' HAVING show_both_site = 1 ORDER BY ', $query1);

        if ($return_query) {
            return $query;
        }

        if (!$union) {
            return $query1;
        }

        $query1 = ') UNION (' . substr($query1, 0, strpos($query1, ' ORDER')) . ')';

        $query1 = str_replace('MIN(tribe_event_end_date.meta_value)', 'MAX(tribe_event_end_date.meta_value)', $query1);
        $query1 = str_replace('SQL_CALC_FOUND_ROWS', '', $query1);

        return '(' . str_replace(' ORDER ', $query1 . ' ORDER ', $query);
    }

}

new WP_Query_Multisite();