<?php

//TODO: organize how include this code parts
require_once get_stylesheet_directory() . '/custom_widgets/carousel/carousel.php';
require_once get_stylesheet_directory() . '/custom_widgets/imageblocks/imageblocks.php';
require_once get_stylesheet_directory() . '/custom_widgets/latestposts.php';
require_once get_stylesheet_directory() . '/custom_widgets/sidebarmenu.php';
require_once get_stylesheet_directory() . '/custom_widgets/projectwidget.php';
require_once get_stylesheet_directory() . '/custom_widgets/latesttweet.php';
require_once get_stylesheet_directory() . '/custom_widgets/contactwidget.php';
require_once get_stylesheet_directory() . '/additional_functions.php';
require_once get_stylesheet_directory() . '/tribe_event_custom.php';

wp_register_script(
    'ttfmake-sections/js/views/picture.js',
    get_stylesheet_directory_uri() . '/sections/js/views/picture.js',
    array(),
    '1.1',
    true
);

wp_register_script(
    'ttfmake-sections/js/views/picture-slide.js',
    get_stylesheet_directory_uri() . '/sections/js/views/picture-slide.js',
    array(),
    '1.1',
    true
);

function add_new_dependencies($dependencies)
{
    $dependencies[] = 'ttfmake-sections/js/views/picture.js';
    $dependencies[] = 'ttfmake-sections/js/views/picture-slide.js';
    return $dependencies;
}

add_action('ttfmake_builder_js_dependencies', 'add_new_dependencies');

function add_new_js_templates($templates)
{
    $templates[] = array(
        'id' => 'picture-slide',
        'builder_template' => 'sections/builder-templates/picture-slide',
        'path' => 'inc/builder/',
    );
    return $templates;
}

add_action('make_builder_js_templates', 'add_new_js_templates');

function updated_tribe_events_event_schedule_details($type = '', $show_time = false)
{
    if (empty($event)) {
        global $post;
        $event = $post;
    }


    if (is_numeric($event)) {
        $event = get_post($event);
    }

    $schedule = '<span class="date-start dtstart">';
    $format = '';
    $date_without_year_format = tribe_get_date_format();
    $date_with_year_format = tribe_get_date_format(true);
    $time_format = get_option('time_format');
    $datetime_separator = tribe_get_option('dateTimeSeparator', ' @ ');
    $time_range_separator = tribe_get_option('timeRangeSeparator', ' - ');
    $microformatStartFormat = tribe_get_start_date($event, false, 'Y-m-dTh:i');
    $microformatEndFormat = tribe_get_end_date($event, false, 'Y-m-dTh:i');

    $settings = array(
        'show_end_time' => true,
        'time' => true,
    );

    $settings = wp_parse_args(apply_filters('tribe_events_event_schedule_details_formatting', $settings), $settings);
    if (!$settings['time']) {
        $settings['show_end_time'] = false;
    }
    if ($show_time == false) {
        $settings = array(
            'show_end_time' => false,
            'time' => false,
        );
    }
    extract($settings);

    if ($type != 'list') {
        $time_range_separator = '-';
        $format = $date_with_year_format;

        // if it starts and ends in the current year then there is no need to display the year
        if (tribe_get_start_date($event, false, 'Y') === date('Y') && tribe_get_end_date($event, false, 'Y') === date('Y')) {
            $format = $date_without_year_format;
        }

    } else {
        $time_range_separator = ' - ';
        $format = $date_with_year_format;
        $time_format = 'H:i';
        $format = 'j M';
        // if it starts and ends in the current year then there is no need to display the year
        if (tribe_get_start_date($event, false, 'Y') === date('Y') && tribe_get_end_date($event, false, 'Y') === date('Y')) {
            $format = $date_without_year_format;
            $format = 'j M';
        }
    }
    if (tribe_event_is_multiday($event)) { // multi-date event

        $format2ndday = apply_filters('tribe_format_second_date_in_range', $format, $event);

        if (tribe_event_is_all_day($event)) {

            if (tribe_get_start_date($event, true, 'M') == tribe_get_end_date($event, true, 'M')) {
                $schedule .= tribe_get_start_date($event, true, 'j');
            } else {
                $schedule .= tribe_get_start_date($event, true, 'j M');
            }
            $schedule .= '<span class="value-title" title="' . $microformatStartFormat . '"></span>';

            $schedule .= '</span>' . $time_range_separator;
            $schedule .= '<span class="date-end dtend">';
            if ($type != 'list') {
                $schedule .= tribe_get_end_date($event, true, $format);
            } else {
                if ($show_time) {
                    if (tribe_get_end_date($event, false, $time_format) == '23:59') {
                        $time = false;
                    }
                    $schedule .= tribe_get_end_date($event, false, $format) . ($time ? ' ' . tribe_get_end_date($event, false, $time_format) : '');
                } else {

                    $schedule .= tribe_get_end_date($event, false, $format);
                }

                if (tribe_get_start_date($event, true, 'Y') !== tribe_get_end_date($event, true, 'Y')) {
                    $schedule .= tribe_get_end_date($event, true, ' y');
                }
            }

        } else {

            if ($show_time) {
                $schedule .= tribe_get_start_date($event, false, $format2ndday) . ($time ? ' ' . tribe_get_start_date($event, false, $time_format) : '');
            } else {
                if (tribe_get_start_date($event, true, 'M') == tribe_get_end_date($event, true, 'M')) {
                    $schedule .= tribe_get_start_date($event, true, 'j') . ($time ? $datetime_separator . tribe_get_start_date($event, false, $time_format) : '');;
                } else {
                    $schedule .= tribe_get_start_date($event, true, 'j M') . ($time ? $datetime_separator . tribe_get_start_date($event, false, $time_format) : '');;
                }
            }
            $schedule .= '<span class="value-title" title="' . $microformatStartFormat . '"></span>';
            $schedule .= '</span>' . $time_range_separator;
            $schedule .= '<span class="date-end dtend">';
            if ($type != 'list') {
                $schedule .= tribe_get_end_date($event, false, $format2ndday) . ($time ? $datetime_separator . tribe_get_end_date($event, false, $time_format) : '');
            } else {
                if ($show_time) {
                    $schedule .= tribe_get_end_date($event, false, $format) . ($time ? ' ' . tribe_get_end_date($event, false, $time_format) : '');;
                } else {
                    $schedule .= tribe_get_end_date($event, false, $format);
                }

                if (tribe_get_start_date($event, true, 'Y') !== tribe_get_end_date($event, true, 'Y')) {
                    $schedule .= tribe_get_end_date($event, true, ' y');
                }

            }

        }

    } elseif (tribe_event_is_all_day($event)) { // all day event

        $schedule .= tribe_get_start_date($event, true, 'j');
        $schedule .= '<span class="value-title" title="' . $microformatStartFormat . '"></span>';
        if ($type != 'list') {
            $schedule .= '/' . tribe_get_start_date($event, true, 'n');
        } else {
            $schedule .= ' ' . tribe_get_start_date($event, true, 'M');
        }
    } else { // single day event

        if (tribe_get_start_date($event, false, 'g:i A') === tribe_get_end_date($event, false, 'g:i A')) { // Same start/end time

            $schedule .= tribe_get_start_date($event, false, $format) . ($time ? ' ' . tribe_get_start_date($event, false, $time_format) : '');
            $schedule .= '<span class="value-title" title="' . $microformatStartFormat . '"></span>';
        } else { // defined start/end time


            $schedule = '<span class="end-time dtend">';
            if ($type != 'list') {

                $schedule .= tribe_get_end_date($event, false, $format);
            } else {


                if ($show_time) {
                    $schedule .= ($show_end_time ? tribe_get_end_date($event, false, $format) : '') . '<span class="value-title" title="' . $microformatEndFormat . '"></span>';

                    $schedule .= '  ' . (tribe_get_start_date($event, false, 'H:i'));

                    $schedule .= '-' . (tribe_get_end_date($event, false, 'H:i'));

                    $schedule .= '</span>';
                } else {

                    $schedule .= tribe_get_end_date($event, false, $format) . '<span class="value-title" title="' . $microformatEndFormat . '"></span>';
                }

            }

        }
    }

    $schedule .= '</span>';

    $schedule = $schedule;

    return apply_filters('tribe_events_event_schedule_details', $schedule);
}


add_action('wp_ajax_ajax_loadmore', 'post_ajax_loadmore');
add_action('wp_ajax_nopriv_ajax_loadmore', 'post_ajax_loadmore');

function post_ajax_loadmore()
{

    $category = get_the_category($_POST['post_id']);

    remove_filter('the_excerpt', 'wpautop');

    $post_sections = ttfmake_get_section_data($_POST['post_id']);

    $post_sections = !empty($_POST['section_id']) ? $post_sections[$_POST['section_id']] : [];
    $post_sections['show-both-sites'] = !empty($post_sections['show_both_sites']) ? $post_sections['show_both_sites'] : '';
    $post_sections['offset'] = $_POST['postperpage'] + $_POST['offset'];
    $post_sections['post__not_in'] = array((($_POST['single']) ? $_POST['post_id'] : ''));
    $post_sections['taxonomy'] = !empty($post_sections['taxonomy']) ? implode('||', $post_sections['taxonomy']) : '';
    $post_sections['post_id'] = $_POST['post_id'];

    if ($_POST['single'] === 'true') {

        $post_sections['columns'] = 4;
        $post_sections['count'] = 4;
        $post_sections['show-title'] = 1;
        $post_sections['show-date'] = 1;
        $post_sections['show-excerpt'] = 1;
        $post_sections['show-author'] = 0;
        $post_sections['show-categories'] = 1;
        $post_sections['show-tags'] = 0;
        $post_sections['show-comments'] = 0;
        $post_sections['thumbnail'] = 'top';
        $post_sections['aspect'] = 'none';
        $post_sections['excerpt-length'] = 55;


        $category_array = array();
        $category_list = wp_get_post_terms($_POST['post_id'], 'category', array("fields" => "all"));

        foreach ($category_list as $category) {
            $category_array[] = 'category:' . $category->slug;
        }

        $category_array = implode('||', $category_array);

        $post_sections['taxonomy'] = $category_array;

    }


    if ($_POST['single'] === 'false') {
        unset($post_sections['tax_query']);
    }

    $query = ttfmp_get_post_list()->build_query($post_sections);
    $content = ttfmp_get_post_list()->render($query, $post_sections);
    echo $content;


    if ($query->found_posts < $_POST['postperpage']) {
        echo '<div style="display: none;" class="post_counter">' . $query->found_posts . '</div>';
    }

    die();


}


/* add some buttons to tinymce */

function wb_add_tinymce_buttons($buttons)
{
    $buttons[] = 'fontsizeselect';
    return $buttons;
}

add_filter("mce_buttons_3", "wb_add_tinymce_buttons");


/*
* Callback function to filter the MCE settings
*/

function my_mce_before_init_insert_formats($style_formats)
{

// Define the style_formats array
    $temp = $style_formats[3];
    unset($style_formats);


    $style_formats = [];

    $style_formats[] = array(
        'title' => 'Underrubrik',
        'block' => 'h2',
    );


    $style_formats[] = array(
        'title' => 'Styckerubrik',
        'block' => 'h5',
    );
    $style_formats[] = array(
        'title' => 'Ingress',
        'block' => 'div',
        'classes' => 'bold-text',
        'wrapper' => true,
    );

    $temp['title'] = 'Pratbubbla';

    $style_formats[] = $temp;

    if (get_current_blog_id() <= 2) {
        $style_formats[] = array(
            'title' => 'Rubrik textbox',
            'block' => 'div',
            'classes' => 'big-title',
            'wrapper' => true,
        );
    }

    $style_formats[] = array(
        'title' => 'Brödtext Sofia pro',
        'block' => 'div',
        'classes' => 'brodtextsofia',
        'wrapper' => true,
    );
    $style_formats[] = array(
        'title' => 'Toppbild',
        'block' => 'h1',
        'classes' => 'random-title',
    );
    $style_formats[] = array(
        'title' => 'Toppbild tagline',
        'block' => 'div',
        'classes' => 'random-subtitle',
        'wrapper' => true,
    );
    $style_formats[] = array(
        'title' => 'Regioner Sidtitel Special',
        'block' => 'h3',
    );


    return $style_formats;

}

// Attach callback to 'tiny_mce_before_init'
add_action('make_style_formats', 'my_mce_before_init_insert_formats');


/* Add fonts */


function add_fonts($fonts_array)
{
    unset($fonts_array);
    $fonts_array['swiftbolditalic'] = array(
        'label' => __('Swift Bold Italic', 'make'),
        'stack' => 'swiftbolditalic'
    );
    $fonts_array['sofiaprobold'] = array(
        'label' => __('Sofia Pro Bold', 'make'),
        'stack' => 'sofiaprobold'
    );
    $fonts_array['sofiapromedium'] = array(
        'label' => __('Sofia Pro Medium', 'make'),
        'stack' => 'sofiapromedium'
    );
    return $fonts_array;
}


add_action('make_get_standard_fonts', 'add_fonts');


/* change post list template */
function change_post_list_template($template_array)
{
    $template_array['plugin'] = get_stylesheet_directory() . '/templates/post-list-item.php';

    return $template_array;

}

add_action('ttfmp_post_list_template_paths', 'change_post_list_template');


/* calculate days ago */

function time_ago($time)
{
    $periods = array("sekund", "minut", "timme", "dag", "vecka", "månad", "år", "decennium");
    $lengths = array("60", "60", "24", "7", "4.35", "12", "10");

    $now = time();

    $difference = $now - $time;
    $tense = "sen";

    for ($j = 0; $difference >= $lengths[$j] && $j < count($lengths) - 1; $j++) {
        $difference /= $lengths[$j];
    }

    $difference = round($difference);

    if ($difference != 1) {
        $periods = array("sekunder", "minuter", "timmar", "dagar", "veckor", "månader", "år", "decennier");
    }

    return "$difference $periods[$j] sen ";
}


/* for twitter */

function makeClickableLinks($s)
{
    return preg_replace('@(https?://([-\w\.]+[-\w])+(:\d+)?(/([\w/_\.#-]*(\?\S+)?[^\.\s])?)?)@', '<a target="blank" rel="nofollow" href="$1" target="_blank">$1</a>', $s);
}


if (!function_exists('ttfmake_widgets_init')) :
    /**
     * Register widget areas
     *
     * @since  1.0.0.
     *
     * @return void
     */
    function equmenia_widgets_init()
    {
        register_sidebar(array(
            'id' => 'sidebar-blog-top',
            'name' => __('Page Blog Top Area', 'make'),
            'description' => ttfmake_sidebar_description('sidebar-blog-top'),
            'before_widget' => '<aside id="%1$s" class="widget %2$s">',
            'after_widget' => '</aside>',
            'before_title' => '<h4 class="widget-title">',
            'after_title' => '</h4>',
        ));

        register_sidebar(array(
            'id' => 'sidebar-page-bottom',
            'name' => __('Page Bottom Banners area', 'make'),
            'description' => ttfmake_sidebar_description('sidebar-page-bottom'),
            'before_widget' => '<aside id="%1$s" class="widget %2$s">',
            'after_widget' => '</aside>',
            'before_title' => '<h4 class="widget-title">',
            'after_title' => '</h4>',
        ));

        if (get_current_blog_id() <= 2) {
            register_sidebar(array(
                'name' => 'Language selector',
                'id' => 'language_selector',
                'before_widget' => '<aside id="%1$s" class="widget %2$s">',
                'after_widget' => '</aside>',
                'before_title' => '<h3>',
                'after_title' => '</h3>',
            ));
        }

        if ((get_current_blog_id() > 2 && !is_admin()) || get_current_blog_id() == MAIN_SUBSITE_ID) {
            register_sidebar(array(
                'name' => 'Subsite menu',
                'id' => 'subsite_menu',
                'before_widget' => '<aside id="%1$s" class="widget %2$s">',
                'after_widget' => '</aside>',
                'before_title' => '<h3>',
                'after_title' => '</h3>',
            ));

            register_sidebar(array(
                'name' => 'Single event sidebar',
                'id' => 'single_event_widget',
                'before_widget' => '<aside id="%1$s" class="widget %2$s">',
                'after_widget' => '</aside>',
                'before_title' => '<h3>',
                'after_title' => '</h3>',
            ));

            register_sidebar(array(
                'name' => 'Black widget area 1',
                'id' => 'black_widget_area_1',
                'before_widget' => '<aside id="%1$s" class="widget %2$s">',
                'after_widget' => '</aside>',
                'before_title' => '<h3>',
                'after_title' => '</h3>',
            ));

            register_sidebar(array(
                'name' => 'Black widget area 2',
                'id' => 'black_widget_area_2',
                'before_widget' => '<aside id="%1$s" class="widget %2$s">',
                'after_widget' => '</aside>',
                'before_title' => '<h3>',
                'after_title' => '</h3>',
            ));

            register_sidebar(array(
                'name' => 'Black widget area 3',
                'id' => 'black_widget_area_3',
                'before_widget' => '<aside id="%1$s" class="widget %2$s">',
                'after_widget' => '</aside>',
                'before_title' => '<h3>',
                'after_title' => '</h3>',
            ));

            register_sidebar(array(
                'name' => 'Black widget area 4',
                'id' => 'black_widget_area_4',
                'before_widget' => '<aside id="%1$s" class="widget %2$s">',
                'after_widget' => '</aside>',
                'before_title' => '<h3>',
                'after_title' => '</h3>',
            ));
        }

        if (get_current_blog_id() > 2) {
            register_sidebar(array(
                'name' => 'Contact icon',
                'id' => 'contact-icon',
                'before_widget' => '<aside id="%1$s" class="widget widget-for-contact-icon %2$s">',
                'after_widget' => '</aside>',
                'before_title' => '<h3>',
                'after_title' => '</h3>',
            ));

            $active_widgets = get_option('sidebars_widgets');

            if (empty ($active_widgets['contact-icon']) || $active_widgets['contact-icon'][0] != 'text-7777') {
                $active_widgets['contact-icon'] = array();
                $widget_text = get_option('widget_text');

                $widget_text[7777] = [
                    'title' => '',
                    'text' => '/kontakt/',
                    'filter' => '',
                    'dw_include' => 0,
                    'dw_logged' => '',
                    'other_ids' => '',
                    'button_title' => '',
                    'add_button1_title' => '',
                    'add_button2_title' => '',
                    'add_button1_link' => '',
                    'add_button2_link' => '',
                    'show_both_sites' => '',
                    'show_all_events' => '',
                    'hide_category' => '',
                    'calendar-link' => '',
                    'taxonomy_array' => '',
                    'region-area-kalender' => '',
                    'local-region-area-kalender' => '',
                    'kalendar-default-view' => '',
                    'classes' => '',
                    'ids' => '',
                ];

                $active_widgets['contact-icon'][] = 'text-7777';

                update_option('widget_text', $widget_text);
                update_option('sidebars_widgets', $active_widgets);
            }
        }
    }
endif;

add_action('widgets_init', 'equmenia_widgets_init');

/* add post styles for related articles */

function add_styles()
{

    if (is_single()) {
        wp_enqueue_style(
            'ttfmp-post-list',
            get_stylesheet_directory_uri() . '/stylesheets/post-list.css',
            array(),
            '1',
            'all'
        );
    }
    if (!is_admin()) {

        wp_register_script('imgLiquid-min', get_stylesheet_directory_uri() . "/javascript/imgLiquid-min.js", array('jquery'));
        wp_enqueue_script('imgLiquid-min');


        wp_register_script('main', get_stylesheet_directory_uri() . "/javascript/main.js", array('jquery'));
        wp_enqueue_script('main');
        wp_localize_script('main', 'mainvalues', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'single' => ((is_single()) ? 'true' : 'false'),
            'post_id' => get_the_ID(),
        ));

//        wp_register_script('extend-swift', get_stylesheet_directory_uri() . "/javascript/extend-plugins/extend-swift.js", array('jquery'));
//        wp_enqueue_script('extend-swift');
        /*wp_register_style( 'mediaquery', get_stylesheet_directory_uri() . '/stylesheets/mediaquery.css', array( 'open-sans' ), '1.0.0' );
        wp_enqueue_style( 'mediaquery' );*/


        /* load more button effect */
        wp_register_script('jquery-ui', get_stylesheet_directory_uri() . "/javascript/jquery-ui.min.js", false, '1.0.0', true);
        wp_enqueue_script('jquery-ui');

        wp_register_script('modernizr', get_stylesheet_directory_uri() . "/javascript/modernizr.custom.js", false, '1.0.0', true);
        wp_enqueue_script('modernizr');

        wp_register_script('classie', get_stylesheet_directory_uri() . "/javascript/classie.js", false, '1.0.0', true);
        wp_enqueue_script('classie');

        wp_register_script('progressButton', get_stylesheet_directory_uri() . "/javascript/progressButton.js", false, '1.0.0', true);
        wp_enqueue_script('progressButton');


        wp_register_script('readmore', get_stylesheet_directory_uri() . "/javascript/readmore.js", false, '1.0.0', true);
        wp_enqueue_script('readmore');

        wp_add_inline_script('main', 'var home_page = "' . get_home_url() . '";', 'before');
    }

}

add_action('wp_enqueue_scripts', 'add_styles');

function pre_build_post_query($args)
{

    if (is_single()) {
        $category = get_the_category();
        $args = array('post_status' => 'publish',
            'post__not_in' => array(get_the_ID()),
            'ignore_sticky_posts' => 1,
            'post_type' => 'post',
            'posts_per_page' => 4,
            'offset' => 0,
            'orderby' => 'date',
            'order' => 'desc',
            'tax_query' => array(array(
                'taxonomy' => 'category',
                'field' => 'slug',
                'terms' => $category[0]->category_nicename
            )));
    }

    return $args;
}

add_action('ttfmp_post_list_query_args', 'pre_build_post_query');


/* add custom field to category */
/* add custom field to category */


add_action('category_add_form_fields', 'category_form_custom_field_add', 10);
add_action('category_edit_form_fields', 'category_form_custom_field_edit', 10, 2);

function category_form_custom_field_add($taxonomy)
{
    ?>
    <div class="form-field">
        <label for="category_related_hide">Hide related articles area</label>
        <input name="category_related_hide" id="category_related_hide" type="checkbox" value="on" size="40"
               aria-required="true"/>
    </div>
    <div class="form-field">
        <label for="category_related_hide">Visa bildbyline</label>
        <input name="show_entry_author" id="show_entry_author" type="checkbox" value="on" size="40"
               aria-required="true"/>
    </div>
    <?php
}

function category_form_custom_field_edit($tag, $taxonomy)
{

    $option_name = 'category_related_hide_' . $tag->term_id;
    $category_related_hide = get_option($option_name);


    $option_name_author = 'show_entry_author_' . $tag->term_id;
    $show_entry_author = get_option($option_name_author);
    ?>
    <tr class="form-field">
        <th scope="row" valign="top"><label for="category_related_hide">Hide related articles area</label></th>
        <td>
            <input <?php if ($category_related_hide == 'on') echo 'checked'; ?> type="checkbox"
                                                                                name="category_related_hide"
                                                                                id="category_related_hide" value="on"
                                                                                size="40" aria-required="true"/>
        </td>
    </tr>
    <tr class="form-field">
        <th scope="row" valign="top"><label for="show_entry_author">Visa bildbyline</label></th>
        <td>
            <input <?php if ($show_entry_author == 'on') echo 'checked'; ?> type="checkbox" name="show_entry_author"
                                                                            id="show_entry_author" value="on" size="40"
                                                                            aria-required="true"/>
        </td>
    </tr>
    <?php


}

/** Save Custom Field Of Category Form */
add_action('created_category', 'category_form_custom_field_save', 10, 2);
add_action('edited_category', 'category_form_custom_field_save', 10, 2);

function category_form_custom_field_save($term_id, $tt_id)
{

    $option_name = 'category_related_hide_' . $term_id;
    update_option($option_name, $_POST['category_related_hide']);

    $option_name = 'show_entry_author_' . $term_id;
    update_option($option_name, $_POST['show_entry_author']);

}


/* add description field to columns */


function add_description_columns($array)
{


    if ($array['id'] != 'picture' && $array['id'] != 'instagram') {
        $array['config'][150] = array(
            'type' => 'textarea',
            'label' => 'Description',
            'name' => 'description',
            'default' => ''
        );

        $array['config'][145] = array(
            'type' => 'checkbox',
            'label' => 'Show title',
            'name' => 'show_title',
            'default' => ''
        );
    }


    return $array;
}


add_action('make_add_section', 'add_description_columns');


function modify_make_prepare_data_section($first_arr, $second_arr)
{
    $first_arr['description'] = $second_arr['description'];
    $first_arr['show_title'] = $second_arr['show_title'];
    return $first_arr;
}

add_action('make_prepare_data_section', 'modify_make_prepare_data_section', 10, 3);


/* load custom admin styles*/

function load_custom_wp_admin_style()
{

    wp_register_style('custom_wp_admin_css', get_stylesheet_directory_uri() . '/stylesheets/admin/main.css', false, '1.0.2');
    wp_enqueue_style('custom_wp_admin_css');


    wp_register_script('main_admin', get_stylesheet_directory_uri() . "/javascript/main_admin.js", array('jquery'));
    wp_enqueue_script('main_admin');


    wp_register_script('multiselect', get_stylesheet_directory_uri() . "/javascript/jquery.multiselect.min.js", array('jquery',
        'jquery-ui-widget'));
    wp_enqueue_script('multiselect');


    if (get_current_blog_id() > 2) {
        wp_register_script('limit_pages', get_stylesheet_directory_uri() . "/javascript/admin/limit_pages.js", false, '1.0.0', true);
        wp_enqueue_script('limit_pages');
    }


    if (function_exists(tribe_events_pro_resource_url)) {
        wp_enqueue_script('calendar-widget-admin', tribe_events_pro_resource_url('calendar-widget-admin.js'), array('jquery'), apply_filters('tribe_events_pro_js_version', '1.1'));

        $prefix = 'tribe-events-pro';
        $tec_pro = Tribe__Events__Main::instance();
        $vendor_url = trailingslashit($tec_pro->pluginUrl) . 'vendor/';

        $css_path = Tribe__Events__Template_Factory::getMinFile($vendor_url . 'select2/select2.css', true);
        $path = Tribe__Events__Template_Factory::getMinFile($vendor_url . 'select2/select2.js', true);
        $chosen_path = Tribe__Events__Template_Factory::getMinFile($vendor_url . 'chosen/public/chosen.jquery.min.js', true);


        wp_enqueue_style($prefix . '-select2-css', $css_path);

        $script_handle = $prefix . '-select2';
        wp_enqueue_script($script_handle, $path, 'jquery', '3.2');
        wp_enqueue_script('chosen-select', $chosen_path, 'jquery', '3.2');
        Tribe__Events__Template_Factory::add_vendor_script($script_handle);
        Tribe__Events__Template_Factory::add_vendor_script('chosen-select');
    }

    global $pagenow;

    $post_type = get_post_type();

    if ($pagenow == 'post.php' && $post_type !== 'te_announcements' && $post_type !== 'epkb_post_type_1' || $pagenow == 'post-new.php' && $post_type !== 'te_announcements' && $post_type !== 'epkb_post_type_1') {

        wp_register_style(
            'imageblocks-widget-admin', get_stylesheet_directory_uri() . '/custom_widgets/imageblocks/assets/css/imageblocks-widget.css'
        );

        wp_register_script(
            'imageblocks-widget-admin', get_stylesheet_directory_uri() . '/custom_widgets/imageblocks/assets/js/imageblocks-widget.js',
            array('media-upload', 'media-views', 'wp-backbone', 'wp-util')
        );

        wp_localize_script(
            'imageblocks-widget-admin',
            'SimpleImageWidget',
            array(
                'l10n' => array(
                    'frameTitle' => __('Choose an Attachment', 'simple-image-widget'),
                    'frameUpdateText' => __('Update Attachment', 'simple-image-widget'),
                    'fullSizeLabel' => __('Full Size', 'simple-image-widget'),
                    'imageSizeNames' => '',
                    'responseError' => __('An error has occurred. Please reload the page and try again.', 'simple-image-widget'),
                ),
                'screenOptionsNonce' => wp_create_nonce('save-siw-preferences'),
            )
        );
        wp_enqueue_script('imageblocks-widget-admin');
        wp_enqueue_script('simple-image-widget-find-posts');
        wp_enqueue_style('imageblocks-widget-admin');

        wp_register_style(
            'carousel-widget-admin', get_stylesheet_directory_uri() . '/custom_widgets/carousel/assets/css/carousel-widget.css'
        );

        wp_register_script(
            'carousel-widget-admin', get_stylesheet_directory_uri() . '/custom_widgets/carousel/assets/js/carousel-widget.js',
            array('media-upload', 'media-views', 'wp-backbone', 'wp-util')
        );

        wp_localize_script(
            'carousel-widget-admin',
            'SimpleImageWidget',
            array(
                'l10n' => array(
                    'frameTitle' => __('Choose an Attachment', 'simple-image-widget'),
                    'frameUpdateText' => __('Update Attachment', 'simple-image-widget'),
                    'fullSizeLabel' => __('Full Size', 'simple-image-widget'),
                    'imageSizeNames' => '',
                    'responseError' => __('An error has occurred. Please reload the page and try again.', 'simple-image-widget'),
                ),
                'screenOptionsNonce' => wp_create_nonce('save-siw-preferences'),
            )
        );


        wp_enqueue_script('carousel-widget-admin');
        wp_enqueue_script('simple-image-widget-find-posts');
        wp_enqueue_style('carousel-widget-admin');

    }


}

add_action('admin_enqueue_scripts', 'load_custom_wp_admin_style');


/* add widget to builder */

function builder_add_widget()
{

    if ($_POST['widget_base'] == 'disabled')
        die();

    require_once(ABSPATH . 'wp-admin/includes/widgets.php');

    $next_id = next_widget_id_number($_POST['widget_base']);

    $widget_id = $_POST['widget_base'] . '-' . $next_id;


    /* save widget to sidebar */


    builder_add_widget_instance($_POST['widget_base'], $next_id);

    $widget_id = builder_add_widget_to_sidebar($_POST['widget_base'], $next_id, $_POST['sidebar_id']);


    ?>
    <li data-id="<?php echo esc_attr($widget_id); ?>">
        <div title="<?php esc_attr_e('Drag-and-drop this widget into place', 'make-plus'); ?>"
             class="ttfmake-sortable-handle">
            <div class="sortable-background"></div>
        </div>
        <div class="ttfmp-widget-list-container">
          <span class="ttfmp-widget-list-type">
            <?php echo $_POST['widget_name']; ?>
          </span>
            <a href="#" class="edit-widget-link ttfmake-overlay-open"
               data-overlay="#ttfmake-overlay-<?php echo esc_attr($widget_id); ?>"
               title="<?php esc_attr_e('Configure widget', 'make-plus'); ?>">
                      <span>
                        <?php esc_html_e('Configure widget', 'make-plus'); ?>
                      </span>
            </a>
            <a href="#" class="remove-widget-link ttfmake-widget-remove"
               title="<?php esc_attr_e('Delete widget', 'make-plus'); ?>">
          <span>
            <?php esc_html_e('Delete widget', 'make-plus'); ?>
          </span>
            </a>
        </div>
    </li>

    <?php die();
}

add_action('wp_ajax_ajax_builder_add_widget', 'builder_add_widget');

function builder_get_widget_pre()
{
    require_once(ABSPATH . 'wp-admin/includes/widgets.php');

    $next_id = next_widget_id_number($_POST['widget_base']);
    $next_id = $next_id - 1;
    $title = $_POST['widget_name'];
    $id_base = $_POST['widget_base'];
    $id = $id_base . '-' . $next_id;

    global $ttfmake_overlay_class, $ttfmake_section_data, $ttfmake_overlay_title, $ttfmake_overlay_id;
    $ttfmake_overlay_class = 'ttfmake-configuration-overlay ttfmake-widget-configuration-overlay';
    $ttfmake_overlay_title = esc_html__('Configure ', 'make-plus') . $title;
    $ttfmake_overlay_id = 'ttfmake-overlay-' . $id;

    // Include the header
    get_template_part('/inc/builder/templates/overlay', 'header');
    global $wp_registered_widget_controls;

    $control = $wp_registered_widget_controls[$id];

    ?>
    <div class="widget-form widget-content">
        <?php
        if (is_callable($control['callback'])) {
            call_user_func_array($control['callback'], $control['params']);
        }
        ?>
        <input type="hidden" name="ttfmp-widgets[]" value="widget-<?php echo esc_attr($id_base); ?>"/>
    </div>
    <?php
    get_template_part('/inc/builder/templates/overlay', 'footer');
}

function builder_get_widget()
{
    wp_die(builder_get_widget_pre());
}


add_action('wp_ajax_ajax_builder_get_widget', 'builder_get_widget');


/* add widget to sidebar functions*/


function builder_add_widget_instance($id_base, $next_id)
{

    $current_widgets = get_option('widget_' . $id_base);

    $current_widgets[$next_id] = array(
        "state" => 'not_activated'
    );

    update_option('widget_' . $id_base, $current_widgets);

}


function builder_add_widget_to_sidebar($id_base, $next_id, $sidebar_id)
{

    $widget_id = $id_base . '-' . $next_id;

    $sidebar_widgets = get_builder_sidebar_widgets($sidebar_id);

    $sidebar_widgets[] = $widget_id;

    set_builder_sidebar_widgets($sidebar_widgets, $sidebar_id);


    return $widget_id;

}


function get_builder_sidebar_widgets($sidebar_id)
{

    $sidebar_widgets = wp_get_sidebars_widgets();

    if (!isset($sidebar_widgets[$sidebar_id])) {
        return false;
    }

    return $sidebar_widgets[$sidebar_id];

}


function set_builder_sidebar_widgets($widgets, $sidebar_id)
{

    $sidebar_widgets = wp_get_sidebars_widgets();

    $sidebar_widgets[$sidebar_id] = $widgets;

    wp_set_sidebars_widgets($sidebar_widgets);

}

/* add widget to sidebar functions end */

function builder_blackstudio_tinymce($pages)
{
    $pages[] = 'post.php';
    return $pages;
}


add_filter('black_studio_tinymce_enable_pages', 'builder_blackstudio_tinymce');


function get_my_widgets()
{
    global $pagenow;

    if ($pagenow == 'widgets.php') {
        foreach ($GLOBALS['wp_registered_sidebars'] as $sidebar_key => $sidebar) {

            if (strpos($sidebar['id'], 'ttfmp') !== false) {
                unset($GLOBALS['wp_registered_sidebars'][$sidebar_key]);
            }

        }
    }

}

add_action('init', 'get_my_widgets');


/* add custom button */
function add_readmore_tc_button()
{
    global $typenow;
    // check user permissions
    if (!current_user_can('edit_posts') && !current_user_can('edit_pages')) {
        return;
    }
    // verify the post type
    if (!in_array($typenow, array('post', 'page')))
        return;
    // check if WYSIWYG is enabled
    if (get_user_option('rich_editing') == 'true') {
        add_filter("mce_external_plugins", "readmore_add_tinymce_plugin");
        add_filter('mce_buttons', 'readmore_register_tc_button');
    }
}

add_action('admin_head', 'add_readmore_tc_button');


function readmore_add_tinymce_plugin($plugin_array)
{
    $plugin_array['readmore_tc_button'] = get_stylesheet_directory_uri() . '/javascript/admin/readmore-button.js';
    return $plugin_array;
}


function readmore_register_tc_button($buttons)
{
    array_push($buttons, "readmore_tc_button");
    return $buttons;
}


/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


if ((empty($_POST['local_widget']) && get_current_blog_id() <= 2)
    || (!isset($_POST['local_widget']) && (int)get_blog_option(get_current_blog_id(), '_default_events_local') == 1)
    || (isset($_POST['local_widget']) && $_POST['local_widget'] != 'yes')) {

    if (!empty($_REQUEST['tmp_event'])) {
        include_once "tmp_event_query.php";
    } else {
        include_once "event_query.php";
    }
}

//Page Slug Body Class
function add_slug_body_class($classes)
{
    global $post;
    if (isset($post)) {
        $classes[] = $post->post_type . '-' . $post->post_name;
    }

    if (get_current_blog_id() > 2) {
        if (get_option('_subsite_deactivate_widgets', 0)) {
            $classes[] = 'without-additional-widgets';
        }
    }

    if (is_page_template('kontakter2.php')) {
        $classes[] = 'page-template-kontakter';
        $classes[] = 'page-template-kontakter-php';
    }

    if (get_theme_mod('use-full-width-logo', 0)) {
        $classes[] = 'full-width-logo';
    }

    return $classes;
}

add_filter('body_class', 'add_slug_body_class');

function add_organization_widget_form($widget, $return, $instance)
{
    if ($widget->id_base == 'tribe-mini-calendar' && get_current_blog_id() > 2) { ?>
        <label>Välj standardvy:<br>
            <select name="<?php echo $widget->get_field_name('kalendar-default-view'); ?>">
                <option value="1" <?php selected(esc_attr(trim($instance['kalendar-default-view'])), trim(esc_attr("1"))) ?>>
                    VECKA
                </option>
                <option value="2" <?php selected(esc_attr(trim($instance['kalendar-default-view'])), trim(esc_attr("2"))) ?>>
                    MÅNAD
                </option>
                <option value="3" <?php selected(esc_attr(trim($instance['kalendar-default-view'])), trim(esc_attr("3"))) ?>>
                    LISTA
                </option>
            </select>
        </label>
        <?php
    }

    if ($widget->id_base == 'tribe-events-adv-list-widget') {
        ?>

        <p>Välj region för att visa regionala evenemang från Equmeniakyrkan.se:</p>
        <?php $customFields = tribe_get_option('custom-fields', false); ?>
        <?php foreach ($customFields as $customField): ?>
            <select name="<?php echo $widget->get_field_name('region-area-kalender'); ?>">
                <option value="0">Region</option>
                <?php $options = explode("\r\n", $customField['values']) ?>
                <?php foreach ($options as $option): ?>
                    <option value="<?php echo esc_attr(trim($option)) ?>" <?php selected(esc_attr(trim($instance['region-area-kalender'])), trim(esc_attr($option))) ?>><?php echo esc_html(stripslashes($option)) ?></option>
                <?php endforeach ?>
            </select>
        <?php endforeach; ?>

        <p>Välj region för att visa evenemang från församlingar i den regionen:</p>
        <?php foreach ($customFields as $customField): ?>
            <select name="<?php echo $widget->get_field_name('local-region-area-kalender'); ?>">
                <option value="0">Select local region</option>
                <?php $options = explode("\r\n", $customField['values']) ?>
                <?php foreach ($options as $option): ?>
                    <option value="<?php echo esc_attr(trim($option)) ?>"
                        <?php selected(esc_attr(trim($instance['local-region-area-kalender'])), trim(esc_attr($option))) ?>>
                        <?php echo esc_html(stripslashes($option)) ?></option>
                <?php endforeach ?>
            </select>
        <?php endforeach; ?>

        <p>Namn på knapp:</p>
        <input id="button_title" name="<?php echo $widget->get_field_name('button_title'); ?>" type="text"
               value="<?php echo $instance['button_title']; ?>">
        <p>Visa alla evenemang:</p>
        <input id="show_all_events" name="<?php echo $widget->get_field_name('show_all_events'); ?>" type="checkbox"
               value="on"
            <?php if ($instance['show_all_events'] == 'on') echo 'checked'; ?> >
        <p>Se kalendern URL:</p>
        <input id="calendar-link" name="<?php echo $widget->get_field_name('calendar-link'); ?>"
               value="<?php echo $instance['calendar-link']; ?>">

        <p>Hide category:</p>
        <input id="hide_category" name="<?php echo $widget->get_field_name('hide_category'); ?>" type="checkbox"
               value="on"
            <?php if ($instance['hide_category'] == 'on') echo 'checked'; ?> >

        <p>Båda organisationer:</p>
        <input id="show_both_sites" name="<?php echo $widget->get_field_name('show_both_sites'); ?>" type="checkbox"
               value="on"
            <?php if ($instance['show_both_sites'] == 'on') echo 'checked'; ?> >

        <p>Additional Button 1 Title:</p>
        <input id="add_button1_title" name="<?php echo $widget->get_field_name('add_button1_title'); ?>" type="text"
               value="<?php echo $instance['add_button1_title']; ?>">
        <p>Additional Button 1 Link:</p>
        <input id="add_button1_link" name="<?php echo $widget->get_field_name('add_button1_link'); ?>" type="text"
               value="<?php echo $instance['add_button1_link']; ?>">
        <p>Additional Button 2 Title:</p>
        <input id="add_button2_title" name="<?php echo $widget->get_field_name('add_button2_title'); ?>" type="text"
               value="<?php echo $instance['add_button2_title']; ?>">
        <p>Additional Button 2 Link:</p>
        <input id="add_button2_link" name="<?php echo $widget->get_field_name('add_button2_link'); ?>" type="text"
               value="<?php echo $instance['add_button2_link']; ?>">
        <?php
        $sites_base = array('1' => '2', '2' => '1');
        $sites_base_name = array('1' => 'Equmenia', '2' => 'Equmeniakyrkan');
        $blog_id = get_current_blog_id();

        $taxonomies = get_object_taxonomies(Tribe__Events__Main::POSTTYPE, 'objects');
        $taxonomies = array_reverse($taxonomies);


        switch_to_blog($sites_base[$blog_id]);
        ?>  <p>Select categories and tags for <?php ?>:</p> <?php
        echo '<select name="' . $widget->get_field_name('taxonomy_array') . '[]" data-placeholder="Select options" class="widefat calendar-widget-add-filter-multiple"  multiple="" tabindex="-1" aria-hidden="true">';

        $selected = '';
        foreach ($taxonomies as $tax) {

            echo sprintf("<optgroup id='%s' label='%s'>", esc_attr($tax->name), esc_attr($tax->labels->name . ' (' . $sites_base_name[$blog_id] . ') '));
            $terms = get_terms($tax->name, array('hide_empty' => false));
            foreach ($terms as $term) {
                if (is_array($instance['taxonomy_array']) && in_array($term->term_id, $instance['taxonomy_array'])) {
                    $selected = 'selected';
                } else {
                    $selected = '';
                }

                echo sprintf("<option " . $selected . " value='%d'>%s</option>", esc_attr($term->term_id), esc_html($term->name));
            }
            echo '</optgroup>';
        }
        echo '</select>';
        switch_to_blog($blog_id);
        ?>

    <?php }

}

add_action('in_widget_form', 'add_organization_widget_form', 9, 3);


function event_widget_update_callback($instance, $new_instance, $old_instance, $widget)
{


    $instance['button_title'] = $new_instance['button_title'];
    $instance['add_button1_title'] = $new_instance['add_button1_title'];
    $instance['add_button2_title'] = $new_instance['add_button2_title'];
    $instance['add_button1_link'] = $new_instance['add_button1_link'];
    $instance['add_button2_link'] = $new_instance['add_button2_link'];
    $instance['show_both_sites'] = $new_instance['show_both_sites'];
    $instance['show_all_events'] = $new_instance['show_all_events'];
    $instance['hide_category'] = $new_instance['hide_category'];
    $instance['calendar-link'] = $new_instance['calendar-link'];
    $instance['taxonomy_array'] = $new_instance['taxonomy_array'];
    $instance['region-area-kalender'] = $new_instance['region-area-kalender'];
    $instance['local-region-area-kalender'] = $new_instance['local-region-area-kalender'];
    $instance['kalendar-default-view'] = $new_instance['kalendar-default-view'];

    return $instance;
}

add_filter('widget_update_callback', 'event_widget_update_callback', 10, 4);


/* dynamic ajax event select */

function event_populate_select()
{
    $blog_id = get_current_blog_id();
    $sites_base = array('1' => '2', '2' => '1');

    switch_to_blog($_POST['blog_id']);

    $terms = get_terms("tribe_events_cat");
    $count = count($terms);

    if ($_POST['blog_id'] == 0) {
        switch_to_blog($sites_base[$blog_id]);
        $terms_network = get_terms("tribe_events_cat");
        $terms = array_merge($terms, $terms_network);
        switch_to_blog($blog_id);
    } else {
        $category = get_term_by('term_id', $_REQUEST['category_area'], 'tribe_events_cat');

        $switched_site = false;
        if (empty($category)) {
            switch_site:
            $switched_site = true;
            switch_to_blog($sites_base[$_REQUEST['blog_id']]);
            $category = get_term_by('term_id', $_REQUEST['category_area'], 'tribe_events_cat');
            switch_to_blog($blog_id);
        }

        switch_to_blog($_REQUEST['blog_id']);
        $category = get_term_by('slug', $category->slug, 'tribe_events_cat');

        if (empty($category) && !$switched_site) {
            goto switch_site;
        }

        switch_to_blog($blog_id);

        $category = get_term_by('slug', $category->slug, 'tribe_events_cat');
        $category->add_id = $_POST['category_area'];
    }

    $new_terms = array();
    foreach ($terms as $term) {
        $new_terms[$term->slug]['ids'][] = $term->term_id;
        $new_terms[$term->slug]['name'] = $term->name;

        if (!empty($category) && ($term->term_id == $category->term_id)) {
            $new_terms[$term->slug]['ids'][] = $category->add_id;
        } elseif (!empty($category) && $term->term_id == $category->add_id) {
            $new_terms[$term->slug]['ids'][] = $category->term_id;
        }
    }


    if ($count > 0) {
        echo "<option value='0'>Verksamhet</option>";
        foreach ($new_terms as $term) {
            $selected = '';
            $key = 0;
            if (in_array($_POST['category_area'], $term['ids'])) {
                $selected = 'selected="selected"';
                $key = array_search($_POST['category_area'], $term['ids'], true);
            }
            echo "<option $selected value=\"" . $term['ids'][$key] . "\">" . $term['name'] . "</option>";
        }
    }
    ?>

    <?php switch_to_blog($blog_id);
}


add_action('wp_ajax_populate_select', 'event_populate_select');
add_action('wp_ajax_nopriv_populate_select', 'event_populate_select');


// Add category slug to the Body class
add_filter('body_class', 'add_category_to_single');
function add_category_to_single($classes, $class = '')
{
    global $post;
    if (is_single()) {

        foreach ((get_the_category($post->ID)) as $category) {
            // add category slug to the $classes array
            $classes[] = $category->category_nicename;
        }


    }

    if (!empty($post) && $post->post_type == 'page') {
        $hide = get_post_meta($post->ID, 'hide_social_buttons', true);
        $is_knowledge_base_page = get_post_meta($post->ID, 'is_knowledge_base_page', true);

        if (!empty($hide)) {
            $classes[] = 'hide_social_buttons';
        }

        if (!empty($is_knowledge_base_page)) {
            $classes[] = 'is-knowledge-base';
        }
    }

    if (get_current_blog_id() > 2) {
        $classes[] = 'subsites';
    }

    if (get_current_blog_id() > 2 && !empty($_REQUEST['customize_theme']) && is_local_admin()) {
        $classes[] = 'subsites-admin';
    }

    if (get_current_blog_id() > 2 && is_local_admin()) {
        $classes[] = 'local-admin';
    }

    // return the $classes array
    return $classes;
}

//Adding the Open Graph in the Language Attributes
function add_opengraph_doctype($output)
{
    return $output . ' xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml"';
}

add_filter('language_attributes', 'add_opengraph_doctype');

//Lets add Open Graph Meta Info

function insert_fb_in_head()
{
    global $post;
    if (!is_singular()) //if it is not a post or a page
        return;
    echo '<meta property="fb:admins" content="YOUR USER ID"/>';
    echo '<meta property="og:title" content="' . get_the_title() . '"/>';
    echo '<meta property="og:type" content="article"/>';
    echo '<meta property="og:url" content="' . get_permalink() . '"/>';
    echo '<meta property="og:site_name" content="Your Site NAME Goes HERE"/>';
    if (!has_post_thumbnail($post->ID)) { //the post does not have featured image, use a default image
        $default_image = "http://example.com/image.jpg"; //replace this with a default image on your server or an image in your media library
        echo '<meta property="og:image" content="' . $default_image . '"/>';
    } else {
        $thumbnail_src = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'medium');
        echo '<meta property="og:image" content="' . esc_attr($thumbnail_src[0]) . '"/>';
    }
    echo "
";
}

//add_action( 'wp_head', 'insert_fb_in_head', 5 );


function str_lreplace($search, $replace, $subject)
{
    $pos = strrpos($subject, $search);

    if ($pos !== false) {
        $subject = substr_replace($subject, $replace, $pos, strlen($search));
    }

    return $subject;
}


/* tiny mce remove buttons */

function remove_tinymce_buttons($buttons)
{
    $remove = array('formatselect');

    return array_diff($buttons, $remove);
}

add_filter('mce_buttons_2', 'remove_tinymce_buttons');


function remove_tinymce_buttons_third($buttons)
{
    $remove = array('fontsizeselect');

    return array_diff($buttons, $remove);
}

add_filter('mce_buttons_3', 'remove_tinymce_buttons_third');


function my_theme_add_editor_styles()
{
    add_editor_style('custom-editor-style.css');
}

add_action('admin_init', 'my_theme_add_editor_styles');


function subscription_redirect_post()
{

    $queried_post_type = get_query_var('post_type');
    $blog_id = get_current_blog_id();
    $redirect_url = '';

    if ($blog_id == 1) {
        $slug = get_post_field('post_name', get_post());
        $redirect_url = '/var-personal/#' . $slug;
    } else {
        $redirect_url = '/personal-och-styrelse/';
    }
    if (is_single() && 'kontakt' == $queried_post_type) {
        wp_redirect($redirect_url, 301);
        exit;
    }
}

add_action('template_redirect', 'subscription_redirect_post');


function validate_gravatar($email)
{
    // Craft a potential url and test its headers
    $hash = md5(strtolower(trim($email)));
    $uri = 'http://www.gravatar.com/avatar/' . $hash . '?d=404';
    $headers = @get_headers($uri);
    if (!preg_match("|200|", $headers[0])) {
        $has_valid_avatar = FALSE;
    } else {
        $has_valid_avatar = TRUE;
    }
    return $has_valid_avatar;
}


function create_subscriptionform()
{
    ob_start();

    echo '<form action="http://news.theletter.se/register/" class="subsform" method="get" name="fpren">
	<input name="distlistkey" type="hidden" value="108833" />
	<input name="gora" type="hidden" value="pren" />
	<input name="tacksida" type="hidden" value="[http://www.equmenia.se]" /><br />
	Namn<br />
	<input name="namn" type="text" /></p>
	<p>E-post<br />
	<input name="email" type="text" /></p>
	<div style="position: absolute; left: -9999px;">Lämna följande fält tomt<br />
	<input tabindex="-1" name="donotfill" type="text" /></div>
	<p><input type="submit" value="Skicka" /></p>
	</form>';

    return trim(ob_get_clean());
}

add_shortcode('subscriptionform', 'create_subscriptionform');


function create_subscriptionform_second()
{
    ob_start();

    echo '<form action="http://news.theletter.se/register/" style="font-size: 17px; font-family: swiftregular;" class="subsform" method="get" name="fpren">
	<input name="distlistkey" type="hidden" value="130142" />
	<input name="gora" type="hidden" value="pren" />
	<input name="tacksida" type="hidden" value="[http://www.equmenia.se]" /><br />
	Namn<br />
	<input name="namn" type="text" /></p>
	<p>E-post<br />
	<input name="email" type="text" /></p>
	<div style="position: absolute; left: -9999px;">Lämna följande fält tomt<br />
	<input tabindex="-1" name="donotfill" type="text" /></div>
	<p><input type="submit" value="Skicka" /></p>
	</form>';

    return trim(ob_get_clean());
}

add_shortcode('subscriptionformsecond', 'create_subscriptionform_second');

function set_breadcrumbs_cookies()
{
    global $post;

    $breadcrumbs = [];

    if (!empty($_COOKIE['breadcrumbs'])) {
        $breadcrumbs = unserialize(stripslashes($_COOKIE['breadcrumbs']));
    }

    if (!$breadcrumbs) {
        $breadcrumbs = [];
    }

    if ($breadcrumbs[0]['post_nempame'] != $post->post_name && !empty($post->post_name)) {
        array_unshift($breadcrumbs, [
            'post_name' => $post->post_name,
            'post_title' => $post->post_title,
        ]);
    }

    foreach ($breadcrumbs as $id => $item) {
        if (($id > 0 && $item['post_name'] == $post->post_name) || empty($item['post_name'])) {
            unset($breadcrumbs[$id]);
        }
    }

    $breadcrumbs = array_values($breadcrumbs);

    if (count($breadcrumbs) > 3) {
        array_pop($breadcrumbs);
    }

    $str = serialize($breadcrumbs);
    setcookie('breadcrumbs', $str, 30 * DAYS_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN);
    $_COOKIE['breadcrumbs'] = $str;
}

//add_action('wp', 'set_breadcrumbs_cookies');


function my_searchwp_live_search_configs($configs)
{
    // override some defaults
    $configs['default'] = array(
        'engine' => 'default',                      // search engine to use (if SearchWP is available)
        'input' => array(
            'delay' => 500,                 // wait 500ms before triggering a search
            'min_chars' => 3,                   // wait for at least 3 characters before triggering a search
        ),
        'results' => array(
            'position' => 'bottom',            // where to position the results (bottom|top)
            'width' => 'css',              // whether the width should automatically match the input (auto|css)
            'offset' => array(
                'x' => -235,                   // x offset (in pixels)
                'y' => 5                    // y offset (in pixels)
            ),
        ),
        'spinner' => array(                         // powered by http://fgnass.github.io/spin.js/
            'lines' => 10,              // number of lines in the spinner
            'length' => 8,               // length of each line
            'width' => 4,               // line thickness
            'radius' => 8,               // radius of inner circle
            'corners' => 1,               // corner roundness (0..1)
            'rotate' => 0,               // rotation offset
            'direction' => 1,               // 1: clockwise, -1: counterclockwise
            'color' => '#000',          // #rgb or #rrggbb or array of colors
            'speed' => 1,               // rounds per second
            'trail' => 60,              // afterglow percentage
            'shadow' => false,           // whether to render a shadow
            'hwaccel' => false,           // whether to use hardware acceleration
            'className' => 'spinner',       // CSS class assigned to spinner
            'zIndex' => 2000000000,      // z-index of spinner
            'top' => '50%',           // top position (relative to parent)
            'left' => '50%',           // left position (relative to parent)
        ),
    );

    return $configs;
}

add_filter('searchwp_live_search_configs', 'my_searchwp_live_search_configs');


add_action('wp_before_admin_bar_render', 'wlwp_admin_bar');

function wlwp_admin_bar()
{
    global $wp_admin_bar;
    $wp_admin_bar->remove_menu('wpseo-menu');
}

add_filter('tribe_get_venue_website_link_label', 'equmenia_tribe_get_website_link_label', 10, 1);
add_filter('tribe_get_event_website_link_label', 'equmenia_tribe_get_website_link_label', 10, 1);
function equmenia_tribe_get_website_link_label($label)
{
    if (strpos($label, 'facebook.com') !== false) {
        $label = 'Mer information';
    }

    return $label;
}


add_action('add_meta_boxes', 'tribe_events_local_settings_metabox');
function tribe_events_local_settings_metabox()
{

    if (get_current_blog_id() <= 2) {
        add_meta_box(
            'tribe-events-local-settings',
            esc_html__('Regions & Local sites', 'equmenia'),
            'tribe_events_local_settings_render',
            'tribe_events',
            'side',
            'default'
        );
    }
}

function tribe_events_local_settings_render($post)
{
    wp_nonce_field('myplugin_inner_custom_box', 'myplugin_inner_custom_box_nonce');

    $region = json_decode(get_post_meta($post->ID, '_event_local_settings_region', true), true);
    $subsite = json_decode(get_post_meta($post->ID, '_event_local_settings_subsite', true), true);

    $html = <<<HTML
    <div class="region-wrapper">
        <label for="event_local_settings_region" style="font-weight: bold;">{region_label}</label> 
        <i data-index="{index}" class="fa fa-minus remove-region"></i> <br>
        <select id="region-{index}" data-index="{index}" name="event_local_settings_region[{index}]" style="width: 100%;">
        <option value="">{select_region_option_label}</option>
            {region_options}
        </select><br>
        <label for="event_local_settings_subsite" style="font-weight: bold;">{site_label}</label><br>
        <select id="site-{index}" data-index="{index}" name="event_local_settings_subsite[{index}]" style="width: 100%;">
        <option value="">{select_site_option_label}</option>
            {sites_options}
        </select>
    </div>
HTML;

    $html_template = '<div class="region-template hidden">';
    $html_template .= $html;
    $html_template .= '</div>';

    $customFields = tribe_get_option('custom-fields', false);
    $customField = array_shift($customFields);
    $options = explode("\r\n", $customField['values']);

    $region_options = '';
    if (!is_array($region)) {
        $region = array($region);
    }
    if (!is_array($region)) {
        $subsite = array($subsite);
    }
    foreach ($region as $index => $val) {
        $region_options = '';
        foreach ($options as $option) {
            $region_options .= '<option value="' . esc_attr(trim($option)) . '"' .
                selected($region[$index], $option, false) . '>' . esc_html(stripslashes($option)) . '</option>';
        }

        $sites = get_sites_by_region($region[$index]);
        $sites_options = '';

        foreach ($sites as $id => $val) {
            $sites_options .= '<option value="' . $id . '"' .
                selected($subsite[$index], $id, false) . '>' . $val . '</option>';
        }

        $tmp_html = $html;

        $replaces = array(
            '{region_label}' => esc_html__('Region', 'equmenia'),
            '{site_label}' => esc_html__('Site', 'equmenia'),
            '{select_region_option_label}' => esc_html__('-- Select region --', 'equmenia'),
            '{select_site_option_label}' => esc_html__('-- Select site --', 'equmenia'),
            '{region_options}' => $region_options,
            '{sites_options}' => $sites_options,
            '{index}' => $index,
        );

        echo str_replace(array_keys($replaces), array_values($replaces), $tmp_html);
    }

    echo '<i class="fa fa-plus add-region"></i>';

    $region_options = '';
    foreach ($options as $option) {
        $region_options .= '<option value="' . esc_attr(trim($option)) . '">' . esc_html(stripslashes($option)) . '</option>';
    }

    $replaces = array(
        '{region_label}' => esc_html__('Region', 'equmenia'),
        '{site_label}' => esc_html__('Site', 'equmenia'),
        '{select_region_option_label}' => esc_html__('-- Select region --', 'equmenia'),
        '{select_site_option_label}' => esc_html__('-- Select site --', 'equmenia'),
        '{region_options}' => $region_options,
    );

    echo str_replace(array_keys($replaces), array_values($replaces), $html_template);

    echo '<script>var region_index = ' . (!is_null($index) ? $index + 1 : 0) . ';</script>';
}

add_action('add_meta_boxes', 'tribe_events_local_suggestion_metabox');
function tribe_events_local_suggestion_metabox()
{
    global $post;
    if (get_current_blog_id() > 2 && $post->post_status == 'publish') {
        add_meta_box(
            'tribe-events-local-suggest',
            esc_html__('Föreslå till nationella webbplatser', 'equmenia'),
            'tribe_events_local_suggestion_render',
            'tribe_events',
            'side',
            'default'
        );
    }
}

function tribe_events_local_suggestion_render($post)
{
    wp_nonce_field('myplugin_inner_custom_box', 'myplugin_inner_custom_box_nonce');

    $pod_1_id = get_post_meta($post->ID, '_suggest_to_1_pod_id', true);
    $pod_2_id = get_post_meta($post->ID, '_suggest_to_2_pod_id', true);

    $original_blog = get_current_blog_id();

    switch_to_blog(1);
    $event_site_1_status = get_post_meta($pod_1_id, 'event_status', true);
    switch_to_blog(2);
    $event_site_2_status = get_post_meta($pod_2_id, 'event_status', true);

    switch_to_blog($original_blog);

    $btn_1_class = 'hidden';
    $status_1_class = 'waiting hidden';
    $site_1_status = 'Väntande';
    $disabled_suggest_to_region = 'disabled';

    if ($event_site_1_status == 'w') {
        $status_1_class = 'waiting';
    } elseif ($event_site_1_status == 'a') {
        $status_1_class = 'approved';
        $site_1_status = 'Godkänd';
    } elseif ($event_site_1_status == 'd') {
        $status_1_class = 'declined';
        $site_1_status = 'Avvisad';
    } else {
        $btn_1_class = $disabled_suggest_to_region = '';

    }

    $btn_2_class = 'hidden';
    $status_2_class = 'waiting hidden';
    $site_2_status = 'Väntande';


    if ($event_site_2_status == 'w') {
        $status_2_class = 'waiting';
    } elseif ($event_site_2_status == 'a') {
        $status_2_class = 'approved';
        $site_2_status = 'Godkänd';
    } elseif ($event_site_2_status == 'd') {
        $status_2_class = 'declined';
        $site_2_status = 'Avvisad';
    } else {
        $btn_2_class = '';
    }

    $html = <<<HTML
    <div class="suggest-wrapper">
        <div class="process hidden">
            <i class="fa fa-spin fa-spinner"></i><span>Vänligen vänta...</span>
        </div>
        
        <div class="action-button">
            <!--<select id="suggest-to-region" name="suggest_to_region" style="width: 100%;" {disabled}>-->
                <!--<option value="all">All</option>-->
                <!--{region_options}-->
            <!--</select><br>-->
            <div id="status-1" class="status {status_1_class}">Equmeniakyrkan status: <strong>{site_1_status}</strong></div>
            <button class="suggest-btn suggest-eqmumeniakyrkan {btn_1_class}" data-site="1" data-event-id="{event_id}" name="suggest_eqmumeniakyrkan" style="width: 100%;">
               Förslå till Equmeniakyrkan
            </button>
        </div> 
        <!--<hr>-->
        <div class="action-button">
            <div id="status-2" class="status {status_2_class}">Equmenia status: <strong>{site_2_status}</strong></div>
            <button class="suggest-btn suggest-eqmumenia {btn_2_class}" data-site="2" data-event-id="{event_id}" 
            name="suggest_eqmumenia"  style="width: 100%;">
                Föreslå till Equmenia
            </button>
        </div>
    </div>
HTML;


    $current_blog_id = get_current_blog_id();
    $region = get_post_meta($post->ID, '_suggest_to_region', true);

    switch_to_blog(1); // Switch to equmeniakyrkan blog

    $customFields = tribe_get_option('custom-fields', false);
    $customField = array_shift($customFields);
    $options = explode("\r\n", $customField['values']);

//    $region_options = '';
//    foreach ($options as $option) {
//        $region_options .= '<option value="' . esc_attr(trim($option)) . '"' .
//            selected($region, $option, false) . '>' . esc_html(stripslashes($option)) . '</option>';
//    }

    switch_to_blog($current_blog_id);

    $replaces = array(
        '{event_id}' => $post->ID,
        '{status_1_class}' => $status_1_class,
        '{status_2_class}' => $status_2_class,
        '{btn_1_class}' => $btn_1_class,
        '{btn_2_class}' => $btn_2_class,
        '{site_1_status}' => $site_1_status,
        '{site_2_status}' => $site_2_status,
//        '{region_options}' => $region_options,
        '{disabled}' => $disabled_suggest_to_region,
    );

    $html = str_replace(array_keys($replaces), array_values($replaces), $html);

    echo $html;
}

add_action('wp_ajax_suggest_event', 'eqm_suggest_event');
function eqm_suggest_event()
{
    $current_blog_id = get_current_blog_id();
    $switch_to_blog_id = $_POST['site_id'];
    $event_id = $_POST['event_id'];
//    $region = !empty($_POST['suggest_to_region']) ? $_POST['suggest_to_region'] : 'all';
//
//    if ($region != 'all') {
//        update_post_meta($event_id, '_suggest_to_region', $region);
//    }

    switch_to_blog($switch_to_blog_id);

    $data = array(
        'event_id' => $event_id,
        'blog_id' => $current_blog_id,
        'event_status' => 'w'
    );

    $pod_id = pods('local_events')->add($data);

    switch_to_blog($current_blog_id);

    update_post_meta($event_id, '_suggest_to_' . $switch_to_blog_id . '_pod_id', $pod_id);

    wp_send_json(array(
        'success' => true,
        'pod_id' => $pod_id
    ));

    wp_die();
}


add_action('save_post', 'tribe_events_local_settings_save_meta_box_data');
function tribe_events_local_settings_save_meta_box_data($post_id)
{
    $key = "show_sidebar." . $post_id . ".site." . get_current_blog_id();
    wp_cache_delete($key, 'show_sidebar');
    global $wpdb, $prefix;

    $wpdb->query("DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE '_region%' AND post_id = {$post_id}");
    if (isset($_POST['event_local_settings_region'])) {
        $regions = $_POST['event_local_settings_region'];
        array_pop($regions);
        update_post_meta($post_id, '_event_local_settings_region', sanitize_text_field(json_encode($regions, JSON_UNESCAPED_UNICODE)));
    } else {
        update_post_meta($post_id, '_event_local_settings_region', '');
    }

    if (isset($_POST['event_local_settings_subsite'])) {
        $subsites = $_POST['event_local_settings_subsite'];
        array_pop($subsites);

        update_post_meta($post_id, '_event_local_settings_subsite', sanitize_text_field(json_encode($subsites)));

        foreach ($regions as $id => $region_name) {
            if (empty($subsites[$id])) {
                update_post_meta($post_id, '_region_' . mb_strtolower($region_name), '1');
            }
        }
        $query = "DELETE FROM {$prefix}_postmeta WHERE key LIKE '_subsite%' AND post_id=" . $post_id;
        $wpdb->query($query);

        $subsites = $_POST['event_local_settings_subsite'];
        array_pop($subsites);

        $wpdb->query("DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE '_subsite%' AND post_id = {$post_id}");
        foreach ($subsites as $subsite) {
            if (!empty($subsite)) {
                update_post_meta($post_id, '_subsite_' . $subsite, 1);
            }
        }

    } else {
        $wpdb->query("DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE '_subsite%' AND post_id = {$post_id}");
    }
}

add_action('wp_ajax_get_subsites_by_region', 'get_subsites_by_region');
function get_subsites_by_region()
{
    $region = $_POST['region'];

    wp_send_json(get_sites_by_region($region));

    wp_die();
}

function get_sites_by_region($search_region)
{
    global $wpdb;

    $blog_data = [];
    $blog_list = get_blog_list(0, 'all');

    foreach ($blog_list as $blog) {
        $blog_data[$blog['blog_id']] = $blog;
    }

    $results = $wpdb->get_results("SELECT * FROM dxcvz_sitemeta WHERE meta_key LIKE '%_subsite_%'", OBJECT);

    $return = [];
    foreach ($results as $item) {
        $id = str_replace('_subsite_', '', $item->meta_key);
        $region = $item->meta_value;
        if (!empty($blog_data[$id]['path'])) {
            $return[$region][$id] = $blog_data[$id]['path'];
        }
    }

    return !empty($return[$search_region]) ? $return[$search_region] : [];
}

/**
 * Get region feed slug
 *
 * @return string
 */
function get_region_feed()
{
    global $wpdb;
    $current_blog_id = get_current_blog_id();
    $region = $wpdb->get_var("SELECT meta_value FROM {$wpdb->sitemeta} WHERE meta_key LIKE '_subsite_{$current_blog_id}'");
    $region = strtolower($region);

    $regions = [
        'mitt' => 'region-mitt',
        'nord' => 'region-nord',
        'öst' => 'region-ost',
        'stockholm' => 'region-stockholm',
        'svealand' => 'region-svealand',
        'syd' => 'region-syd',
        'väst' => 'region-vast',
    ];

    return $regions[$region];

}

function get_region_name()
{
    global $wpdb;
    $current_blog_id = get_current_blog_id();
    eqm_switch_blog($current_blog_id . '___');
    $region = $wpdb->get_var("SELECT meta_value FROM {$wpdb->sitemeta} WHERE meta_key LIKE '_subsite_{$current_blog_id}'");

    return $region;

}

// AJAX. Add Event to my site
add_action('wp_ajax_add_event_to_my_site', 'add_event_to_my_site');
function add_event_to_my_site()
{
    $post_id = !empty($_POST['post_id']) ? $_POST['post_id'] : null;
    $blog_id = !empty($_POST['blog_id']) ? $_POST['blog_id'] : null;
    $event_blog_id = !empty($_POST['event_blog_id']) ? $_POST['event_blog_id'] : null;

    if (empty($post_id)) {
        wp_send_json([
            'success' => false,
            'message' => 'Field post_id doesn\'t empty'
        ]);
    }

    if (empty($blog_id)) {
        wp_send_json([
            'success' => false,
            'message' => 'Field blog_id doesn\'t empty'
        ]);
    }

    if (empty($event_blog_id)) {
        wp_send_json([
            'success' => false,
            'message' => 'Field event_blog_id doesn\'t empty'
        ]);
    }

    $current_blog_id = get_current_blog_id();
    switch_to_blog($event_blog_id);

    update_post_meta($post_id, '_subsite_added_' . $blog_id, 1);

    switch_to_blog($current_blog_id);

    wp_send_json([
        'success' => true,
    ]);

    wp_die();
}


// AJAX. Remove Event from my site
add_action('wp_ajax_remove_event_from_my_site', 'remove_event_from_my_site');
function remove_event_from_my_site()
{
    $post_id = !empty($_POST['post_id']) ? $_POST['post_id'] : null;
    $blog_id = !empty($_POST['blog_id']) ? $_POST['blog_id'] : null;
    $event_blog_id = !empty($_POST['event_blog_id']) ? $_POST['event_blog_id'] : null;

    if (empty($post_id)) {
        wp_send_json([
            'success' => false,
            'message' => 'Field post_id doesn\'t empty'
        ]);
    }

    if (empty($blog_id)) {
        wp_send_json([
            'success' => false,
            'message' => 'Field blog_id doesn\'t empty'
        ]);
    }

    if (empty($event_blog_id)) {
        wp_send_json([
            'success' => false,
            'message' => 'Field event_blog_id doesn\'t empty'
        ]);
    }

    $current_blog_id = get_current_blog_id();
    switch_to_blog($event_blog_id);

    delete_post_meta($post_id, '_subsite_added_' . $blog_id, 1);

    switch_to_blog($current_blog_id);

    wp_send_json([
        'success' => true,
    ]);

    wp_die();
}

function is_added_event_to_my_site($post_id, $blog_id, $global_blog_id)
{
    $current_blog_id = get_current_blog_id();
    switch_to_blog($global_blog_id);

    $res = get_post_meta($post_id, '_subsite_added_' . $blog_id, true);

    switch_to_blog($current_blog_id);
    if (!empty($res)) {
        return true;
    }

    return false;
}

add_action('admin_footer-edit.php', 'custom_bulk_admin_footer');

function custom_bulk_admin_footer()
{
    global $post_type;

    if ($post_type == 'local_events') {
        ?>
        <script type="text/javascript">
            jQuery(document).ready(function () {
                jQuery("select[name='action'] option[value='edit']").remove();
                jQuery("select[name='action'] option[value='trash']").remove();
                jQuery("select[name='action2'] option[value='edit']").remove();
                jQuery("select[name='action2'] option[value='trash']").remove();

                jQuery('<option>').val('approve').text('<?php _e('Approve')?>')
                    .appendTo("select[name='action']");
                jQuery('<option>').val('approve').text('<?php _e('Approve')?>')
                    .appendTo("select[name='action2']");

                jQuery('<option>').val('decline').text('<?php _e('Decline')?>')
                    .appendTo("select[name='action']");
                jQuery('<option>').val('decline').text('<?php _e('Decline')?>')
                    .appendTo("select[name='action2']");
            });
        </script>
        <?php
    }
}

add_action('load-edit.php', 'custom_bulk_action');

function custom_bulk_action()
{
    $wp_list_table = _get_list_table('WP_Posts_List_Table');
    $action = $wp_list_table->current_action();

    switch ($action) {
        case 'approve':
            foreach ($_REQUEST['post'] as $post_id) {
                $pods = pods('local_events', $post_id);
                $pods->save(['event_status' => 'a']);
            }
            break;
        case 'decline':
            foreach ($_REQUEST['post'] as $post_id) {
                $pods = pods('local_events', $post_id);
                $pods->save(['event_status' => 'd']);
            }
            break;
        default:
            return;
    }

}

global $pagenow;
if ('edit.php' == $pagenow && isset($_GET['post_type']) && $_GET['post_type'] == 'local_events') {

    add_filter('post_row_actions', 'wpse_125800_row_actions', 10, 2);
    function wpse_125800_row_actions($actions, $post)
    {
        unset($actions['inline hide-if-no-js']);
        unset($actions['view']);
        unset($actions['edit']);
        unset($actions['duplicate']);
        unset($actions['trash']);
        unset($actions['rocket_purge']);

        return $actions;
    }
}

function my_column_meta_value_mask_key($value, $object_id, $column)
{
    $custom_field_key = 'event_title';
    $current_blog_id = get_current_blog_id();
    if ('column-meta' == $column->get_type()) {
        if ($custom_field_key == $column->get_field()) {
            $pods = pods('local_events', $object_id);

            $switch_to_blog = $pods->field('blog_id');
            $event_id = $pods->field('event_id');
            switch_to_blog($switch_to_blog);
            $event = get_post($event_id);
            $value = '<a href="' . $event->guid . '" target="blank">' . $event->post_title . '</a>';
            switch_to_blog($current_blog_id);
        }

        if ('blog_id' == $column->get_field()) {
            $pods = pods('local_events', $object_id);

            $switch_to_blog = $pods->field('blog_id');
            switch_to_blog($switch_to_blog);
            $value = '<a href="' . get_option('siteurl') . '" target="blank">' . get_option('blogname') . '</a>';
            switch_to_blog($current_blog_id);
        }

        if ('event_region' == $column->get_field()) {
            $pods = pods('local_events', $object_id);

            $switch_to_blog = $pods->field('blog_id');
            $event_id = $pods->field('event_id');
            switch_to_blog($switch_to_blog);
            $region = get_post_meta($event_id, '_suggest_to_region', true);
            if (empty($region)) {
                $region = 'All';
            }
            $value = $region;
            switch_to_blog($current_blog_id);
        }
    }

    return $value;
}

add_filter('cac/column/meta/value', 'my_column_meta_value_mask_key', 10, 3);

function disable_new_posts()
{
    global $submenu;
    unset($submenu['edit.php?post_type=local_events'][10]);

    // Hide link on listing page
    if (isset($_GET['post_type']) && $_GET['post_type'] == 'local_events') {
        echo '<style type="text/css">
            #favorite-actions, .add-new-h2, .tablenav:not(.top), .page-title-action { display:none; }
        </style>';
    }
}

add_action('admin_menu', 'disable_new_posts');

add_filter('views_edit-local_events', 'cyb_remove_pending_filter');
function cyb_remove_pending_filter($views)
{
    unset($views['publish']);
    unset($views['draft']);
    unset($views['mine']);
    $views = wpse_30331_manipulate_views('local_events', $views);
    return $views;
}

function wpse_30331_manipulate_views($what, $views)
{
    global $wpdb;

    $waiting = $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->posts p JOIN $wpdb->postmeta pm ON (p.ID=pm.post_id) WHERE pm.meta_key = 'event_status' AND pm.meta_value = 'w' AND p.post_type = '$what'");
    $approved = $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->posts p JOIN $wpdb->postmeta pm ON (p.ID=pm.post_id) WHERE pm.meta_key = 'event_status' AND pm.meta_value = 'a' AND p.post_type = '$what'");
    $declined = $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->posts p JOIN $wpdb->postmeta pm ON (p.ID=pm.post_id) WHERE pm.meta_key = 'event_status' AND pm.meta_value = 'd' AND p.post_type = '$what'");

    $views['waiting'] = "<a href='?post_type=local_events&post_status=waiting'>Waiting ($waiting)</a>";
    $views['approved'] = "<a href='?post_type=local_events&post_status=approved'>Approved ($approved)</a>";
    $views['declined'] = "<a href='?post_type=local_events&post_status=declined'>Declined ($declined)</a>";


    return $views;
}

function search_filter($query)
{
    if (isset($_GET['post_type']) && $_GET['post_type'] == 'local_events' && isset($_GET['post_status'])) {
        $query->set('meta_query', array(
            array(
                'key' => 'event_status',
                'value' => substr($_GET['post_status'], 0, 1),
            )
        ));
    }
}

add_action('pre_get_posts', 'search_filter');

add_action('tribe_events_venue_metabox_before_google_map', 'eqm_te_venue_metabox_before_google_map');

function eqm_te_venue_metabox_before_google_map($post)
{
    $_EventRoom = get_post_meta($post->ID, '_Room', true);
    $html = <<<HTML
<tr>
    <td>Rum</td>
    <td><input type="text" name="venue[Room]" value="{event_room}"></td>
</tr>
HTML;

    $html = str_replace('{event_room}', $_EventRoom, $html);

    echo $html;
}

add_action('save_post_' . Tribe__Events__Main::POSTTYPE, 'eqm_save_venue_data', 1, 2);
function eqm_save_venue_data($postID, $post = null)
{
//    echo '<pre>'; print_r([$postID, $_POST]); die();
    update_post_meta($postID, '_Room', $_POST['venue']['Room']);
}

add_action('tribe_events_single_meta_venue_section_end', 'eqm_display_venue_room', 10);
function eqm_display_venue_room()
{
    global $post;

    $room = get_post_meta($post->ID, '_Room', true);

    if (!empty($room)) {
        echo "Lokal: " . $room . "";
    }
}

add_action('before_delete_post', 'eqm_delete_event_suggestion', 1, 1);
function eqm_delete_event_suggestion($postID)
{
    global $post_type, $wpdb;

    $current_blog_id = get_current_blog_id();
    if ($post_type == Tribe__Events__Main::POSTTYPE) {
        $pod_1_id = get_post_meta($postID, '_suggest_to_1_pod_id', true);
        $pod_2_id = get_post_meta($postID, '_suggest_to_2_pod_id', true);

        if (!empty($pod_1_id)) {
            switch_to_blog(1);
            $result = $wpdb->delete($wpdb->posts, array('ID' => $pod_1_id));
            switch_to_blog($current_blog_id);
        }

        if (!empty($pod_2_id)) {
            switch_to_blog(2);
            $result = $wpdb->delete($wpdb->posts, array('ID' => $pod_2_id));
            switch_to_blog($current_blog_id);
        }

    }
}


if (get_current_blog_id() > 2 && get_current_blog_id() != MAIN_SUBSITE_ID) {
    // Remove Equmeniakyrkan | Equmenia menu for subsites of copy
    add_action('admin_init', 'remove_menu');
    function remove_menu()
    {
        global $wpdb;
        $prefix = $wpdb->prefix;
        $post_id = $wpdb->get_var("SELECT ID FROM {$prefix}posts WHERE post_type LIKE 'nav_menu_item' AND post_name LIKE 'equmeniakyrkan-equmenia'");

        if (!empty($post_id)) {
            wp_delete_post($post_id, true);
            wp_reset_postdata();
        }

        $term_id = $wpdb->get_var("SELECT term_id FROM {$prefix}terms WHERE slug LIKE 'equmeniakyrkan-equmenia'");

        if (!empty($term_id)) {
            wp_delete_term($term_id, 'nav_menu');
        }
    }
}


add_action('admin_init', 'save_custom_options');
function save_custom_options()
{
    global $pagenow, $wpdb;

    if ('site-info.php' == $pagenow && $_REQUEST['id'] > 2 /* && $_GET['id'] != MAIN_SUBSITE_ID */) {
        if (isset($_REQUEST['action']) && 'update-site' == $_REQUEST['action']) {

            // Use a default value here if the field was not submitted.
            if (isset($_POST['blog']['_subsite_region'])) {
                $wpdb->query("UPDATE dxcvz_sitemeta 
                  SET meta_value = '{$_POST['blog']['_subsite_region']}' 
                  WHERE meta_key LIKE '_subsite_{$_POST['id']}'");
            }

            if (isset($_POST['blog']['_subsite_deactivate_widgets'])) {
                update_blog_option($_POST['id'], '_subsite_deactivate_widgets',
                    $_POST['blog']['_subsite_deactivate_widgets']);
            }

            if (isset($_POST['blog']['_subsite_show_events_in_widgets'])) {
                update_blog_option($_POST['id'], '_subsite_show_events_in_widgets',
                    $_POST['blog']['_subsite_show_events_in_widgets']);
            }
        }
    }

    if ('options.php' == $pagenow && get_current_blog_id() > 2) {
        $current_blog_id = get_current_blog_id();
        if (isset($_REQUEST['action']) && 'update' == $_REQUEST['action']) {

            if (isset($_POST['blog']['_show_events_from_national'])) {
                update_blog_option($current_blog_id, '_show_events_from_national',
                    $_POST['blog']['_show_events_from_national']);
            }

            if (isset($_POST['blog']['_default_events_local'])) {
                update_blog_option($current_blog_id, '_default_events_local',
                    (int)$_POST['blog']['_default_events_local']);
            }

            if (isset($_POST['blog']['_show_events_from_local_region'])) {
                update_blog_option($current_blog_id, '_show_events_from_local_region',
                    $_POST['blog']['_show_events_from_local_region']);
            }

            if (isset($_POST['blog']['_show_posts_from_national'])) {
                update_blog_option($current_blog_id, '_show_posts_from_national',
                    $_POST['blog']['_show_posts_from_national']);
            }

            if (isset($_POST['blog']['_show_posts_from_local_region'])) {
                update_blog_option($current_blog_id, '_show_posts_from_local_region',
                    $_POST['blog']['_show_posts_from_local_region']);
            }
        }
    }
}

// Additional settings foк subsites
add_action('admin_footer', 'subsites_custom_options');
function subsites_custom_options()
{
    global $pagenow, $wpdb;

    if ('site-info.php' == $pagenow && $_GET['id'] > 2 /* && $_GET['id'] != MAIN_SUBSITE_ID */):

        ?>
        <table id="subsites_custom_options">
            <tr>
                <th scope="row">Region</th>
                <td>
                    <select name="blog[_subsite_region]">
                        <?php
                        $subsite_region = $wpdb->get_var("SELECT meta_value FROM {$wpdb->prefix}sitemeta WHERE meta_key LIKE '_subsite_"
                            . $_GET['id'] . "'");
                        $customFields = tribe_get_option('custom-fields', false);

                        ?>
                        <?php foreach ($customFields as $customField): ?>
                            <?php $options = explode("\r\n", $customField['values']) ?>
                            <?php foreach ($options as $option): ?>
                                <option value="<?php echo esc_attr(trim($option)) ?>"
                                    <?php selected(esc_attr(trim($subsite_region)), trim(esc_attr($option))) ?>><?php echo esc_html(stripslashes($option)) ?></option>
                            <?php endforeach ?>
                        <?php endforeach; ?>

                    </select>
                </td>
            </tr>
            <tr>
                <th scope="row">Avaktivera nationella widgets</th>
                <td>
                    <input name="blog[_subsite_deactivate_widgets]" type="hidden" value="0">
                    <input name="blog[_subsite_deactivate_widgets]" type="checkbox"
                           value="1" <?php checked(get_blog_option($_GET['id'], '_subsite_deactivate_widgets')); ?>/>
                </td>
            </tr>
            <tr>
                <th scope="row">Visa evenemang i den nationella kalendern</th>
                <td>
                    <input name="blog[_subsite_show_events_in_widgets]" type="hidden" value="0">
                    <input name="blog[_subsite_show_events_in_widgets]" type="checkbox"
                           value="1" <?php checked(get_blog_option($_GET['id'], '_subsite_show_events_in_widgets')); ?>/>
                </td>
            </tr>
        </table>

        <script>
            jQuery(function ($) {
                $('.form-table').append($('#subsites_custom_options').children());
            });
        </script>
    <? elseif ('options-general.php' == $pagenow && get_current_blog_id() > 2):
        $current_blog_id = get_current_blog_id();
        ?>
        <table id="subsites_custom_options2">
            <tr style="display: block">
                <th scope="row">Gör alla nationella event tillgängliga i kalendern</th>
                <td>
                    <input name="blog[_show_events_from_national]" type="hidden" value="0">
                    <input name="blog[_show_events_from_national]" type="checkbox"
                           value="1" <?php checked(get_blog_option($current_blog_id, '_show_events_from_national')); ?>>
                </td>
            </tr>
            <tr style="display: block">
                <th scope="row">Visa i standardläge regionala och nationella event i kalenderwidgeten</th>
                <td>
                    <input name="blog[_default_events_local]" type="radio" value="0"
                        <?php checked((int)get_blog_option($current_blog_id, '_default_events_local'), 0); ?>> Ja
                    <input name="blog[_default_events_local]" type="radio" value="1"
                        <?php checked((int)get_blog_option($current_blog_id, '_default_events_local'), 1); ?>> Nej
                </td>
            </tr>
            <!--            <tr style="display: block">-->
            <!--                <th scope="row">Show events from local region</th>-->
            <!--                <td>-->
            <!--                    <input name="blog[_show_events_from_local_region]" type="hidden" value="0">-->
            <!--                    <input name="blog[_show_events_from_local_region]" type="checkbox" value="1" -->
            <?php //checked(get_blog_option($current_blog_id, '_show_events_from_local_region'));
            ?><!-->-->
            <!--                </td>-->
            <!--            </tr>-->
            <!--            <tr style="display: block">-->
            <!--                <th scope="row">Visa inlägg från regionen</th>-->
            <!--                <td>-->
            <!--                    <input name="blog[_show_posts_from_national]" type="hidden" value="0">-->
            <!--                    <input name="blog[_show_posts_from_national]" type="checkbox" value="1" -->
            <?php //checked(get_blog_option($current_blog_id, '_show_posts_from_national'));
            ?><!-->-->
            <!--                </td>-->
            <!--            </tr>-->
            <!--            <tr style="display: block">-->
            <!--                <th scope="row">Visa inlägg från andra församlingar i samma region</th>-->
            <!--                <td>-->
            <!--                    <input name="blog[_show_posts_from_local_region]" type="hidden" value="0">-->
            <!--                    <input name="blog[_show_posts_from_local_region]" type="checkbox" value="1" -->
            <?php //checked(get_blog_option($current_blog_id, '_show_posts_from_local_region'));
            ?><!-->-->
            <!--                </td>-->
            <!--            </tr>-->
        </table>

        <script>
            jQuery(function ($) {
                $('.form-table').append($('#subsites_custom_options').children());
                $('.form-table').append($('#subsites_custom_options2').children());
            });
        </script>
    <?php endif; ?>

    <?php

}

add_filter('admin_body_class', 'rw_admin_body_class');
function rw_admin_body_class($classes)
{
    global $post;
    $screen = get_current_screen();
    if (get_current_blog_id() == MAIN_SUBSITE_ID) {
        $classes .= ' main-subsite';
    }

    if (get_current_blog_id() > 2) {
        $classes .= ' subsites-admin';
    }

    if (in_array($post->ID, [37171, 37221, 2])) {
        $classes .= ' home-alternatives';
    }


    if (get_current_blog_id() > 2 && is_local_admin()) {
        $classes .= ' local-admin';
    }

    return $classes;
}

if (get_current_blog_id() > 2) {
    add_filter('get_pages', 'eqm_get_pages', 10, 2);
    function eqm_get_pages($pages, $r)
    {
        foreach ($pages as $key => $page) {
            if (!in_array($page->ID, [37171, 37221, 2])) {
                unset($pages[$key]);
            }
        }
//    die();

        return $pages;
    }
}

// Fix problem with showing left sidebar
add_filter('make_has_sidebar', 'eqm_has_sidebar');
function eqm_has_sidebar($show_sidebar)
{
    global $wpdb;

    $prefix = $wpdb->prefix;
    $post_data = get_post();

    $key = "show_sidebar." . get_the_ID() . ".site." . get_current_blog_id();

    if (get_current_blog_id() > 2) {
        if (get_post_meta(get_the_ID(), 'activate_left_sidebar', true) != 1) {
            return false;
        }
    }

    $menu_slug = wp_cache_get($key, 'show_sidebar', false, $found);

    if (empty($found)) {

        $menu_slug = $wpdb->get_var("SELECT " . $prefix . "terms.slug FROM " . $prefix . "postmeta
                                     RIGHT JOIN " . $prefix . "term_relationships
                                     ON " . $prefix . "postmeta.post_id = " . $prefix . "term_relationships.object_id
                                     RIGHT JOIN " . $prefix . "terms
                                     ON " . $prefix . "term_relationships.term_taxonomy_id = " . $prefix . "terms.term_id
                                     WHERE " . $prefix . "postmeta.meta_key = '_menu_item_object_id' AND " . $prefix . "postmeta.meta_value = '" . get_the_ID() . "'"
        );


        /* If custom links*/
        if (!isset($menu_slug)) {

            $menu_slug = $wpdb->get_var("SELECT " . $prefix . "terms.slug FROM " . $prefix . "postmeta
                                     RIGHT JOIN " . $prefix . "term_relationships
                                     ON " . $prefix . "postmeta.post_id = " . $prefix . "term_relationships.object_id
                                     RIGHT JOIN " . $prefix . "terms
                                     ON " . $prefix . "term_relationships.term_taxonomy_id = " . $prefix . "terms.term_id
                                     WHERE " . $prefix . "postmeta.meta_key = '_menu_item_url' AND " . $prefix . "postmeta.meta_value LIKE '%" . $post_data->post_name . "%'");

        }

        wp_cache_set($key, $menu_slug, 'show_sidebar', 3600);
    }

    if (empty($menu_slug)) {
        $show_sidebar = false;
    }

    return $show_sidebar;
}

add_filter('the_content2', 'wpautop');

function eqm_remove_those_menu_items()
{
    if (get_current_blog_id() > 2 && get_current_blog_id() != 17) {
        remove_submenu_page('edit.php?post_type=envira', 'envira-gallery-settings');
        remove_submenu_page('edit.php?post_type=envira', 'envira-gallery-addons');
    }
}

add_action('admin_menu', 'eqm_remove_those_menu_items', 999);


add_filter('envira_gallery_tab_nav2', 'eqm_envira_gallery_tab_nav2', 10, 1);
function eqm_envira_gallery_tab_nav2($tabs)
{
    if (get_current_blog_id() > 2 && get_current_blog_id() != 17) {
//        unset($tabs['misc'], $tabs['config'], $tabs['lightbox'], $tabs['mobile']);
        unset($tabs['misc'], $tabs['config'], $tabs['mobile']);
    }

    return $tabs;
}

function my_searchwp_query_main_join($sql, $engine)
{
    global $wpdb;
    $my_meta_key = 'search_priority';  // the meta_key you want to order by
    $sql = $sql . " LEFT JOIN {$wpdb->postmeta} ON {$wpdb->posts}.ID = {$wpdb->postmeta}.post_id AND {$wpdb->postmeta}.meta_key = '{$my_meta_key}'";

    return $sql;
}

add_filter('searchwp_query_main_join', 'my_searchwp_query_main_join', 10, 2);

function my_searchwp_query_orderby($orderby)
{
    global $wpdb;
    $my_order = "DESC"; // sort in descending order

    $new_orderby = "ORDER BY {$wpdb->postmeta}.meta_value + 0 {$my_order}, " . str_replace(['ORDER BY'], '', $orderby);

    return $new_orderby;
}

add_filter('searchwp_query_orderby', 'my_searchwp_query_orderby');

/**
 * Register meta box(es).
 */
function search_wp_register_meta_boxes()
{
    add_meta_box(
        'search-wp-meta-box-id',
        __('Search WP Priority', 'textdomain'),
        'search_wp_meta_boxes_display_callback',
        array('post', 'page'),
        'side');
}

add_action('add_meta_boxes', 'search_wp_register_meta_boxes');

/**
 * Register meta box(es).
 */
function page_assign_to_menu_meta_box()
{
    add_meta_box(
        'page-assign-to-menu',
        __('Assign to menu', 'textdomain'),
        'assign_to_menu_display_callback',
        array('page'),
        'side');
}

add_action('add_meta_boxes', 'page_assign_to_menu_meta_box');

/**
 * Meta box display callback.
 *
 * @param WP_Post $post Current post object.
 */
function assign_to_menu_display_callback($post)
{
    global $wpdb;

    $query = "SELECT {$wpdb->postmeta}.post_id, {$wpdb->terms}.name
FROM {$wpdb->postmeta}
  RIGHT JOIN {$wpdb->term_relationships} ON {$wpdb->postmeta}.post_id = {$wpdb->term_relationships}.object_id
  RIGHT JOIN {$wpdb->terms} ON {$wpdb->term_relationships}.term_taxonomy_id = {$wpdb->terms}.term_id
WHERE {$wpdb->postmeta}.meta_key = '_menu_item_object_id' AND {$wpdb->postmeta}.meta_value = '{$post->ID}'";

    $menu_id = get_post_meta($post->ID, '_assign_to_menu', true);
    $menu_list = $wpdb->get_results($query, ARRAY_A);

    if (empty($menu_list) && !empty($_GET['debug1'])) {
        $query = "SELECT CASE {$wpdb->postmeta}.post_id 
          WHEN pm2.meta_value THEN 1 ELSE 0 END as priority, {$wpdb->terms}.slug 
          FROM {$wpdb->postmeta}
            RIGHT JOIN {$wpdb->term_relationships}
              ON {$wpdb->postmeta}.post_id = {$wpdb->term_relationships}.object_id
         LEFT JOIN {$wpdb->postmeta} pm2 
         ON ({$wpdb->postmeta}.meta_value = pm2.post_id AND pm2.meta_key = '_assign_to_menu')
         RIGHT JOIN {$wpdb->terms}
         ON {$wpdb->term_relationships}.term_taxonomy_id = {$wpdb->terms}.term_id
         WHERE {$wpdb->postmeta}.meta_key = '_menu_item_url' AND {$wpdb->postmeta}.meta_value LIKE '{$post->post_name}%' 
         GROUP BY slug
         ORDER BY priority DESC";

        $menu_list = $wpdb->get_results($query, ARRAY_A);
    }

    echo '<select name="assign_to_menu">';
    echo '<option value="">-- Select Menu --</option>';
    if (!empty($menu_list)) {
        foreach ($menu_list as $menu_item) {
            ?>
            <option value="<?= $menu_item['post_id']; ?>" <?php selected(esc_attr(trim($menu_item['post_id'])), $menu_id) ?>><?= $menu_item['name']; ?></option>
            <?php
        }
    }
    echo '</select>';
}

/**
 * Meta box display callback.
 *
 * @param WP_Post $post Current post object.
 */
function search_wp_meta_boxes_display_callback($post)
{
    $val = get_post_meta($post->ID, 'search_priority', true);
    echo '<input name="search_priority" value="' . $val . '" style="width: 100%">';
}

/**
 * Save meta box content.
 *
 * @param int $post_id Post ID
 */
function search_wp_save_meta_box($post_id)
{
    global $post;

    if ($post->post_type == 'page' && get_current_blog_id() == 2) {
        remove_all_actions('save_post');
        // Update the post
        $page_data = array(
            'ID' => $post_id,
            'post_date' => $post_date = date("Y-m-d H:i:s"),
            'post_date_gmt' => $post_date
        );

        // Update the post into the database
        wp_update_post($page_data);
    }

    update_post_meta($post_id, 'search_priority', $_REQUEST['search_priority']);

    if ($post->post_type == 'page') {
        if (!empty($_REQUEST['assign_to_menu'])) {
            update_post_meta($post_id, '_assign_to_menu', $_REQUEST['assign_to_menu']);
        } else {
            delete_post_meta($post_id, '_assign_to_menu');
        }
    }
}

add_action('save_post', 'search_wp_save_meta_box', 100);

function my_searchwp_indexer_tag_attributes($tags)
{

    // do not index img tags at all
    if (isset($tags['a'])) {
        unset($tags['a']);
    }

    // index our custom Reference data attribute on <article>s
    $tags['article'] = array('data-reference');

    return $tags;
}

add_filter('searchwp_indexer_tag_attributes', 'my_searchwp_indexer_tag_attributes');

add_filter('attribute_escape', 'eqm_attribute_escape', 10, 2);
function eqm_attribute_escape($safe_text, $text)
{
    if (get_current_blog_id() > 2) {
        if (strpos($safe_text, 'wp-customizer') !== false && is_local_admin()) {
            return $safe_text . ' subsites-admin';
        }
    }

    return $safe_text;
}

function admin_redirects()
{
    global $pagenow;

    if (is_local_admin() && get_current_blog_id() > 2) {
        // Redirect from Rocket page settings for local admin
        if ($pagenow == 'options-general.php' && isset($_GET['page']) && $_GET['page'] == 'wprocket') {
            wp_redirect(admin_url('/'), 301);
            exit;
        }
    }
}

add_action('admin_init', 'admin_redirects');

add_filter('make_read_more_text', 'podcast_make_read_more_text', 10, 1);
function podcast_make_read_more_text($text)
{
    global $post;

    if ($post->post_type == 'podcast') {
        return 'Läs mer';
    } else {
        return $text;
    }
}

add_filter('pods_meta_default_box_title', 'eqm_pods_meta_default_box_title');

function eqm_pods_meta_default_box_title()
{
    return 'Fler fält';
}

//add_action( 'switch_blog', 'eqm_switch_blog' );
function eqm_switch_blog($new_blog)
{
    if (!empty($_REQUEST['tmp_event']) && (17 == $new_blog || '17___' == $new_blog)) {
        file_put_contents(__DIR__ . '/switch_blog.txt',
            $new_blog . "\n" . print_r(debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS), 1) . "\n\n", FILE_APPEND);
    }
}

function large_network_remove_wp_admin_bar_my_sites_menu()
{
    remove_action('admin_bar_menu', 'wp_admin_bar_my_sites_menu', 20);
}

add_action('add_admin_bar_menus', 'large_network_remove_wp_admin_bar_my_sites_menu');

function large_network_replacement_my_sites_menu($wp_admin_bar)
{
    if (!current_user_can('manage_network')) {
        // bail.. no network menu for you!
        return;
    }

    $wp_admin_bar->add_menu(array(
        'id' => 'prefix-my-sites',
        'title' => __('My Sites'),
        'href' => admin_url('my-sites.php'),
    ));

    $wp_admin_bar->add_menu(array(
        'id' => 'prefix-network-admin',
        'parent' => 'prefix-my-sites',
        'title' => __('Network Dashboard'),
        'href' => network_admin_url(),
    ));

    $wp_admin_bar->add_menu(array(
        'id' => 'prefix-network-sites',
        'parent' => 'prefix-my-sites',
        'title' => __('Network Sites'),
        'href' => network_admin_url('sites.php'),
    ));

    $wp_admin_bar->add_menu(array(
        'id' => 'prefix-network-users',
        'parent' => 'prefix-my-sites',
        'title' => __('Network Users'),
        'href' => network_admin_url('users.php'),
    ));
}

add_action('admin_bar_menu', 'large_network_replacement_my_sites_menu', 20);

function large_network_skip_get_blogs_of_user_with_many_sites($null, $object_id, $meta_key)
{
    global $wpdb;

    // Don't proceed if fetching a specific meta key, or the current user is not a super admin
    if ($meta_key || !is_super_admin()) {
        return $null;
    }

    // Ok, then fetch all the user meta (remove this filter to do so)
    remove_filter('get_user_metadata', __FUNCTION__, 10, 4);
    $keys = get_user_meta($object_id);
    add_filter('get_user_metadata', __FUNCTION__, 10, 4);

    // And loop through them
    foreach ($keys as $key => $value) {
        // Ignore non-capability meta keys
        if ('capabilities' !== substr($key, -12)) {
            continue;
        }

        // Ignore meta keys w/o the base_prefix
        if ($wpdb->base_prefix && 0 !== strpos($key, $wpdb->base_prefix)) {
            continue;
        }

        // Attempt to get the blog id from the string
        $blog_id = str_replace(array($wpdb->base_prefix, '_capabilities'), '', $key);

        // If it's not numeric, ignore this too
        if (!is_numeric($blog_id)) {
            continue;
        }

        // Ok, let's black-list this capability meta from being sent back
        unset($keys[$key]);
    }

    return $keys;
}

add_filter('get_user_metadata', 'large_network_skip_get_blogs_of_user_with_many_sites', 10, 3);

add_filter('http_request_timeout', 'eqm_http_request_timeout', 999);
function eqm_http_request_timeout($timeout)
{
    return 10;
}

add_filter('manage_posts_columns', 'manage_posts_columns', 999);
function manage_posts_columns($columns)
{
    global $post_type;
    if ($post_type == 'tribe_events' && is_local_admin()) {
        unset($columns['tags'], $columns['expirationdate'], $columns['gadwp_stats'], $columns['comments']);
    }

    return $columns;
}

add_action('init', 'eqm_ical_request');
function eqm_ical_request()
{
    if (strpos($_SERVER['REQUEST_URI'], '/export-calendar/ical') !== false) {
//	    ini_set("display_errors", "On");
//	    error_reporting(E_ERROR);
        if (!empty($_REQUEST['action']) && $_REQUEST['action'] == 'export') {
            ob_end_clean();
            ob_end_flush();
            require_once "additional-lib/vendor/autoload.php";

            date_default_timezone_set('Europe/Stockholm');

            $GLOBALS['ical'] = 1;

            // 1. Create new calendar
            $vCalendar = new \Eluceo\iCal\Component\Calendar(get_bloginfo('wpurl'));

            $vCalendar->setName(get_bloginfo('name'));
            $vCalendar->setMethod('PUBLISH');
            $vCalendar->setForceInspectOrOpen(true);

            $vCalendar->setTimezone('Europe/Stockholm');


            $events = TribeEventsQuery::getEvents([
                'eventDisplay' => 'custom',
                'start_date' => tribe_beginning_of_day(date('Y-m-d')),
                'posts_per_page' => 100
            ]);

//			echo "<pre>";
//			echo $events->request;
            $current_blog_id = get_current_blog_id();
            foreach ($events as $post) {

                // 2. Create an event

                $is_local_event = is_local_event($post->guid);
                $switch_blog_id = get_blog_id_by_event_guid($post->guid, $is_local_event);

                switch_to_blog($switch_blog_id);

//				print_r([$post, tribe_get_event_link($post)]);


                $vEvent = new \Eluceo\iCal\Component\Event();
                $vEvent->setDtStart(new \DateTime($post->EventStartDate));
                $vEvent->setDtEnd(new \DateTime($post->EventEndDate));
                if (tribe_event_is_all_day($post)) {
                    $vEvent->setNoTime(true);
                }

                $vEvent->setSummary(html_entity_decode(get_the_title($post)));
                $vEvent->setDescription(strip_tags(tribe_events_get_the_excerpt($post)));
                $vEvent->setUrl(tribe_get_event_link($post));
                // Adding Timezone (optional)
                $vEvent->setUseTimezone(true);

                // 3. Add event to calendar
                $vCalendar->addComponent($vEvent);

            }

            switch_to_blog($current_blog_id);

            // 4. Set headers
            header('Content-Type: text/calendar; charset=utf-8;');
            header('Content-Disposition: attachment; filename="cal.ics";');

            // 5. Output
            echo $vCalendar->render();
            die();
        }
    }
}

add_filter('make_customizer_sections', 'eqm_customizer_sections', 11);

function eqm_customizer_sections($sections)
{
    $available_site_ids = [149, 152];

    if (!in_array(get_current_blog_id(), $available_site_ids)) {
        return $sections;
    }

    $theme_prefix = 'ttfmake_';
    $panel = 'ttfmake_general';

    /**
     * Logo
     */
    $sections['logo'] = array(
        'panel' => $panel,
        'title' => __('Logo', 'make'),
        'options' => array(
            'use-full-width-logo' => array(
                'setting' => array(
                    'sanitize_callback' => 'absint',
                ),
                'control' => array(
                    'label' => __('Full width logo', 'make'),
                    'type' => 'checkbox',
                ),
            ),
            'full-width-logo-regular' => array(
                'setting' => array(
                    'sanitize_callback' => 'esc_url_raw',
                ),
                'control' => array(
                    'control_type' => 'TTFMAKE_Customize_Image_Control',
                    'label' => __('Full Width Regular Logo', 'make'),
                    'context' => $theme_prefix . 'full-width-logo-regular',
                ),
            ),
            'full-width-logo-retina' => array(
                'setting' => array(
                    'sanitize_callback' => 'esc_url_raw',
                ),
                'control' => array(
                    'control_type' => 'TTFMAKE_Customize_Image_Control',
                    'label' => __('Full Width Retina Logo (2x)', 'make'),
                    'description' => __('The Retina Logo should be twice the size of the Regular Logo.', 'make'),
                    'context' => $theme_prefix . 'full-width-logo-retina',
                ),
            ),
//            'full-width-logo-mobile'          => array(
//                'setting' => array(
//                    'sanitize_callback' => 'esc_url_raw',
//                ),
//                'control' => array(
//                    'control_type' => 'TTFMAKE_Customize_Image_Control',
//                    'label'        => __( 'Full Width Mobile Logo', 'make' ),
//                    'context'      => $theme_prefix . 'full-width-logo-mobile',
//                ),
//            ),
            'logo-regular' => array(
                'setting' => array(
                    'sanitize_callback' => 'esc_url_raw',
                ),
                'control' => array(
                    'control_type' => 'TTFMAKE_Customize_Image_Control',
                    'label' => __('Regular Logo', 'make'),
                    'context' => $theme_prefix . 'logo-regular',
                ),
            ),
            'logo-retina' => array(
                'setting' => array(
                    'sanitize_callback' => 'esc_url_raw',
                ),
                'control' => array(
                    'control_type' => 'TTFMAKE_Customize_Image_Control',
                    'label' => __('Retina Logo (2x)', 'make'),
                    'description' => __('The Retina Logo should be twice the size of the Regular Logo.', 'make'),
                    'context' => $theme_prefix . 'logo-retina',
                ),
            ),
        ),
    );

    return $sections;
}

add_action('before_rocket_clean_domain', 'eqm_before_rocket_clean_domain');

function eqm_before_rocket_clean_domain()
{
    $current_blog_id = get_current_blog_id();

    $menuTmpPath = dirname(__FILE__) . '/../make/menu.tmp/';
    $fileNamePattern = '.site.' . $current_blog_id;

    foreach (new DirectoryIterator($menuTmpPath) as $fileInfo) {
        if ($fileInfo->isDot()) {
            continue;
        }

        if (substr_count($fileInfo->getFilename(), $fileNamePattern) > 0) {
            unlink($menuTmpPath . $fileInfo->getFilename());
        }
    }
}


function exclude_post_types($should_index, WP_Post $post)
{
//    return false;

    // Add all post types you don't want to make searchable.
    $include_post_types = array('page', 'post', 'tribe_events');
    if (false === $should_index) {
        return false;
    }

    return in_array($post->post_type, $include_post_types);
}

// Hook into Algolia to manipulate the post that should be indexed.
add_filter('algolia_should_index_searchable_post', 'exclude_post_types', 999, 2);
add_filter('algolia_should_index_post', 'exclude_post_types', 999, 2);


/**
 * This method exists for enabling SearchWP plugins on the subsites
 */
//add_action('init', 'enable_search', 99);
function enable_search()
{
    if (!empty($_GET['activate_search'])) {
        $search_plugins = [
            "searchwp-fuzzy/searchwp-fuzzy.php",
            "searchwp-like/searchwp-like.php",
            "searchwp-live-ajax-search/searchwp-live-ajax-search.php",
            "searchwp-stemmer-swedish/searchwp-stemmer-swedish.php",
            "searchwp-term-highlight/searchwp-term-highlight.php",
            "searchwp-term-synonyms/searchwp-term-synonyms.php",
            "searchwp/searchwp.php"
        ];

        global $wpdb;

        $blog_ids = $wpdb->get_col("SELECT blog_id FROM {$wpdb->blogs} WHERE blog_id > 3;");

        foreach ($blog_ids as $blog_id) {
            switch_to_blog($blog_id);
            $active_plugins = get_option('active_plugins', []);

            if (!empty($active_plugins)) {
                $is_changed = false;
                foreach ($search_plugins as $name) {
                    if (!in_array($name, $active_plugins)) {
                        $active_plugins[] = $name;
                        $is_changed = true;
                    }
                }

                if ($is_changed) {
                    update_option('active_plugins', $active_plugins);
                }
            }
        }

        die();
    }
}